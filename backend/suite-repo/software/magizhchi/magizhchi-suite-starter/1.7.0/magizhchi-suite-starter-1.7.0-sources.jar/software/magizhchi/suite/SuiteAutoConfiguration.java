package software.magizhchi.suite;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import software.magizhchi.suite.activity.SuiteActivity;
import software.magizhchi.suite.auth.DelegationVerifier;
import software.magizhchi.suite.auth.SuiteTokens;
import software.magizhchi.suite.brain.SuiteBrainController;
import software.magizhchi.suite.brain.SuiteTool;
import software.magizhchi.suite.calls.SuiteCalls;
import software.magizhchi.suite.chat.SuiteChat;
import software.magizhchi.suite.events.SuiteEventHandler;
import software.magizhchi.suite.events.SuiteEvents;
import software.magizhchi.suite.events.SuiteEventsController;
import software.magizhchi.suite.events.SuiteEventsSubscriber;
import software.magizhchi.suite.orgs.SuiteOrgs;
import software.magizhchi.suite.friends.SuiteFriends;
import software.magizhchi.suite.pay.SuitePay;
import software.magizhchi.suite.pay.SuitePayController;
import software.magizhchi.suite.pay.SuitePurchases;
import software.magizhchi.suite.provider.ProviderClient;

import java.util.List;

/**
 * Adds the suite beans to any app that has this library on its classpath. Each bean stays inert until its settings
 * are present, so adding the dependency alone changes nothing about how an app runs.
 */
@AutoConfiguration
@EnableConfigurationProperties(SuiteProperties.class)
public class SuiteAutoConfiguration {

    @Bean
    @ConditionalOnMissingBean
    public SuiteTokens suiteTokens(SuiteProperties props) {
        return new SuiteTokens(props);
    }

    @Bean
    @ConditionalOnMissingBean
    public DelegationVerifier suiteDelegationVerifier(SuiteProperties props) {
        return new DelegationVerifier(props.getJwt().getSecret(), props.getSuite().getAppName());
    }

    @Bean(destroyMethod = "close")
    @ConditionalOnMissingBean
    public SuiteActivity suiteActivity(SuiteProperties props, ObjectProvider<ObjectMapper> mapper) {
        return new SuiteActivity(props.getSuite().getAppId(), props.getPa().getUrl(), props.paSecret(),
                mapper.getIfAvailable(ObjectMapper::new));
    }

    @Bean
    @ConditionalOnMissingBean
    public ProviderClient suiteProviderClient(SuiteProperties props) {
        // A plain mapper: Provider's wire format is fixed and must not follow the app's own naming settings.
        return new ProviderClient(props.getProvider().getUrl(), props.getProvider().getApiKey(), new ObjectMapper());
    }

    /** Organisations from Magizhchi ID, seen as this app (magizhchi.suite.app-name). Uses the ID provision secret. */
    @Bean
    @ConditionalOnMissingBean
    public SuiteOrgs suiteOrgs(SuiteProperties props) {
        return new SuiteOrgs(props.idUrl(), props.getProvisionSecret(), props.getSuite().getAppName(), new ObjectMapper());
    }

    /** The suite's one friend and block list, kept in Magizhchi ID, for this app's Friends screen. */
    @Bean
    @ConditionalOnMissingBean
    public SuiteFriends suiteFriends(SuiteProperties props) {
        return new SuiteFriends(props.idUrl(), props.getProvisionSecret(), props.getSuite().getAppName(), new ObjectMapper());
    }

    /** Calls through Magizhchi Meet, the suite's calling hub, for this app's signed-in person. */
    @Bean
    @ConditionalOnMissingBean
    public SuiteCalls suiteCalls(SuiteProperties props) {
        return new SuiteCalls(props.getMeet().getUrl(), props.getProvisionSecret(), props.getSuite().getAppName(), new ObjectMapper());
    }

    /** Box chat (Magizhchi Messenger) for this app's signed-in person: the Magizhchi bar's chat pass. */
    @Bean
    @ConditionalOnMissingBean
    public SuiteChat suiteChat(SuiteProperties props) {
        return new SuiteChat(props.getBox().getUrl(), props.getProvisionSecret(), props.getSuite().getAppName(), new ObjectMapper());
    }

    /** Magizhchi Pay: payments through ID's one checkout, delivered back to this app's activate endpoint. */
    @Bean
    @ConditionalOnMissingBean
    public SuitePay suitePay(SuiteProperties props) {
        return new SuitePay(props.idUrl(), props.getProvisionSecret(), props.getSuite().getAppName(), props.activateUrl(), new ObjectMapper());
    }

    /** Publishes this app's events to the suite's events bus in PA (magizhchi.suite.app-id + the PA secret). */
    @Bean(destroyMethod = "close")
    @ConditionalOnMissingBean
    public SuiteEvents suiteEvents(SuiteProperties props) {
        return new SuiteEvents(props.getSuite().getAppId(), props.getPa().getUrl(), props.paSecret());
    }

    /** Receives other apps' events, only in a web app that declares at least one {@link SuiteEventHandler}. */
    @Configuration(proxyBeanMethods = false)
    @ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
    @ConditionalOnClass(name = "org.springframework.web.servlet.DispatcherServlet")
    static class Events {

        @Bean
        @ConditionalOnBean(SuiteEventHandler.class)
        @ConditionalOnMissingBean
        SuiteEventsController suiteEventsController(List<SuiteEventHandler> handlers, SuiteProperties props) {
            return new SuiteEventsController(handlers, props.paSecret());
        }

        @Bean
        @ConditionalOnBean(SuiteEventHandler.class)
        @ConditionalOnMissingBean
        SuiteEventsSubscriber suiteEventsSubscriber(List<SuiteEventHandler> handlers, SuiteProperties props) {
            return new SuiteEventsSubscriber(handlers, props.getSuite().getAppId(), props.getPa().getUrl(), props.paSecret(), props.eventsUrl());
        }
    }

    /** Answers ID's activate call, only in a web app that declares a {@link SuitePurchases} bean. */
    @Configuration(proxyBeanMethods = false)
    @ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
    @ConditionalOnClass(name = "org.springframework.web.servlet.DispatcherServlet")
    static class Purchases {

        @Bean
        @ConditionalOnBean(SuitePurchases.class)
        @ConditionalOnMissingBean
        SuitePayController suitePayController(SuitePurchases purchases, SuiteProperties props) {
            return new SuitePayController(purchases, props.getProvisionSecret());
        }
    }

    /** The Suite Brain endpoints, only in a web app that declares at least one {@link SuiteTool}. */
    @Configuration(proxyBeanMethods = false)
    @ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
    @ConditionalOnClass(name = "org.springframework.web.servlet.DispatcherServlet")
    static class Brain {

        @Bean
        @ConditionalOnBean(SuiteTool.class)
        @ConditionalOnMissingBean
        SuiteBrainController suiteBrainController(DelegationVerifier verifier, SuiteProperties props, List<SuiteTool> tools) {
            if (props.getSuite().getAppName().isBlank()) {
                throw new IllegalStateException("This app declares suite tools, so set magizhchi.suite.app-name (e.g. \"Magizhchi Books\").");
            }
            return new SuiteBrainController(verifier, props, tools);
        }
    }
}
