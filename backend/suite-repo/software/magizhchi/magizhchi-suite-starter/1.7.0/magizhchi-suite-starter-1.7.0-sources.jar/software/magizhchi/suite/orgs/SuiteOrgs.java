package software.magizhchi.suite.orgs;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import software.magizhchi.suite.SuiteException;

import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Organisations from Magizhchi ID, as this app sees them: which organisations a person works in (and their role), an
 * organisation's members, and linking this app's own company records to organisations. Answers are cached for a
 * minute, so an app can call this on every request without hammering ID.
 *
 * <p>Roles: {@code role} is the organisation role (OWNER, ADMIN, MEMBER), the same in every app. {@code appRole} is
 * this app's own role for the person when an owner set one (e.g. ACCOUNTANT in Books), else null: then the app
 * derives its role from {@code role}.
 *
 * <p>{@code designation} (1.6.0) is what the person does, in the owner's words ("Manager", "HR"), or null. It is not a
 * permission. {@link #teammates} finds people by it: "call the manager", "send this to HR".
 */
public class SuiteOrgs {

    public record Org(String id, String name, String role, String appRole, String externalId, String designation) {
        public Org(String id, String name, String role, String appRole, String externalId) { this(id, name, role, appRole, externalId, null); }
        public boolean isOwner() { return "OWNER".equals(role); }
        public boolean managesMembers() { return "OWNER".equals(role) || "ADMIN".equals(role); }
    }

    public record Member(String accountId, String email, String name, String role, String appRole, String designation) {
        public Member(String accountId, String email, String name, String role, String appRole) { this(accountId, email, name, role, appRole, null); }
    }

    /**
     * Someone the person works with. {@code match}: how well their designation answered the ask (4 same words, 3
     * initials such as HR = Human Resources, 2 one of its words, 1 a shared stem; 0 when nothing was asked).
     * {@code usesApp}: whether they may use this app; an app can still email or ring someone who doesn't.
     */
    public record Teammate(String accountId, String email, String name, String designation, String role,
                           String orgId, String orgName, boolean usesApp, int match) {}

    public record Members(String id, String name, String externalId, List<Member> members) {}

    public record Linked(String id, String name, boolean created) {}

    static final Duration TTL = Duration.ofSeconds(60);

    private final String idUrl;
    private final String secret;
    private final String app;
    private final ObjectMapper mapper;
    private final HttpClient http;
    private final Clock clock;
    private final Map<String, Cached<?>> cache = new ConcurrentHashMap<>();

    private record Cached<T>(T value, Instant until) {}

    public SuiteOrgs(String idUrl, String secret, String app, ObjectMapper mapper) {
        this(idUrl, secret, app, mapper, HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build(), Clock.systemUTC());
    }

    SuiteOrgs(String idUrl, String secret, String app, ObjectMapper mapper, HttpClient http, Clock clock) {
        this.idUrl = idUrl == null ? "" : idUrl.trim().replaceAll("/+$", "");
        this.secret = secret == null ? "" : secret.trim();
        this.app = app == null ? "" : app.trim();
        this.mapper = mapper;
        this.http = http;
        this.clock = clock;
    }

    /** True when the ID address, the provision secret and this app's name are all set. */
    public boolean configured() {
        return !idUrl.isBlank() && !secret.isBlank() && !app.isBlank();
    }

    /** The organisations this person is an active member of and may use this app in. Empty when they have none. */
    public List<Org> orgsFor(String email) {
        String e = email == null ? "" : email.trim().toLowerCase();
        return cached("p:" + e, () -> {
            JsonNode res = get("/api/v1/provision/orgs?email=" + enc(e) + "&app=" + enc(app));
            List<Org> out = new ArrayList<>();
            for (JsonNode n : res) out.add(new Org(text(n, "id"), text(n, "name"), text(n, "role"), text(n, "appRole"), text(n, "externalId"), text(n, "designation")));
            return List.copyOf(out);
        });
    }

    /** The person's membership in one organisation (for this app), or null when they are not in it. */
    public Org membership(String email, String orgId) {
        for (Org o : orgsFor(email)) if (o.id().equals(orgId)) return o;
        return null;
    }

    /** The organisation's active members who may use this app, to sync the app's own member list. */
    public Members members(String orgId) {
        return cached("o:" + orgId, () -> {
            JsonNode n = get("/api/v1/provision/orgs/" + enc(orgId) + "?app=" + enc(app));
            List<Member> list = new ArrayList<>();
            for (JsonNode m : n.path("members")) {
                list.add(new Member(text(m, "accountId"), text(m, "email"), text(m, "name"), text(m, "role"), text(m, "appRole"), text(m, "designation")));
            }
            return new Members(text(n, "id"), text(n, "name"), text(n, "externalId"), List.copyOf(list));
        });
    }

    /**
     * The people this person works with whose designation answers {@code ask} ("manager", "hr", "accounts"), best
     * first, across every organisation they are in; a blank ask lists everyone they work with. Only ever ask for the
     * person signed in to this app. Empty when nobody matches: say so, never guess someone else.
     */
    public List<Teammate> teammates(String email, String ask) {
        String e = email == null ? "" : email.trim().toLowerCase();
        String q = ask == null ? "" : ask.trim();
        return cached("t:" + e + "|" + q.toLowerCase(), () -> {
            JsonNode res = get("/api/v1/provision/orgs/teammates?email=" + enc(e) + "&ask=" + enc(q) + "&app=" + enc(app));
            List<Teammate> out = new ArrayList<>();
            for (JsonNode n : res) {
                out.add(new Teammate(text(n, "accountId"), text(n, "email"), text(n, "name"), text(n, "designation"), text(n, "role"),
                        text(n, "orgId"), text(n, "orgName"), n.path("usesApp").asBoolean(false), n.path("match").asInt(0)));
            }
            return List.copyOf(out);
        });
    }

    /**
     * Ties one of this app's companies to an organisation, creating the organisation (owned by {@code ownerEmail}, who
     * must have a Magizhchi ID account) the first time. Safe to call again: the same company always gets the same
     * organisation.
     */
    public Linked link(String externalId, String name, String ownerEmail) {
        requireConfigured();
        String body;
        try {
            body = mapper.writeValueAsString(Map.of("app", app, "externalId", externalId, "name", name, "ownerEmail", ownerEmail));
        } catch (IOException e) {
            throw new IllegalStateException(e);
        }
        JsonNode n = send(HttpRequest.newBuilder(URI.create(idUrl + "/api/v1/provision/orgs/link"))
                .timeout(Duration.ofSeconds(10))
                .header("Content-Type", "application/json")
                .header("X-Provision-Secret", secret)
                .POST(HttpRequest.BodyPublishers.ofString(body)).build());
        cache.clear();
        return new Linked(text(n, "id"), text(n, "name"), n.path("created").asBoolean(false));
    }

    /** Forget cached answers, e.g. right after the app changed something in ID. */
    public void forget() {
        cache.clear();
    }

    @SuppressWarnings("unchecked")
    private <T> T cached(String key, java.util.function.Supplier<T> load) {
        requireConfigured();
        Instant now = clock.instant();
        Cached<?> c = cache.get(key);
        if (c != null && c.until().isAfter(now)) return (T) c.value();
        T v = load.get();
        if (cache.size() > 5000) cache.clear();
        cache.put(key, new Cached<>(v, now.plus(TTL)));
        return v;
    }

    private JsonNode get(String path) {
        return send(HttpRequest.newBuilder(URI.create(idUrl + path))
                .timeout(Duration.ofSeconds(10))
                .header("X-Provision-Secret", secret)
                .GET().build());
    }

    private JsonNode send(HttpRequest req) {
        HttpResponse<String> res;
        try {
            res = http.send(req, HttpResponse.BodyHandlers.ofString());
        } catch (IOException e) {
            throw new SuiteException(503, "id_unreachable", "Magizhchi ID can't be reached right now. Try again in a minute.");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new SuiteException(503, "interrupted", "Interrupted while calling Magizhchi ID.");
        }
        JsonNode n;
        try {
            n = res.body() == null || res.body().isBlank() ? mapper.createObjectNode() : mapper.readTree(res.body());
        } catch (IOException e) {
            n = mapper.createObjectNode();
        }
        if (res.statusCode() >= 300) {
            String msg = n.path("message").asText(n.path("error").asText("Magizhchi ID answered " + res.statusCode() + "."));
            throw new SuiteException(res.statusCode() == 403 ? 503 : res.statusCode(), "id_" + res.statusCode(),
                    res.statusCode() == 403 ? "This app's Magizhchi ID secret is wrong (magizhchi.provision-secret)." : msg);
        }
        return n;
    }

    private void requireConfigured() {
        if (!configured()) throw SuiteException.notConfigured("Magizhchi ID organisations (magizhchi.id.url, magizhchi.provision-secret, magizhchi.suite.app-name)");
    }

    private static String text(JsonNode n, String field) {
        JsonNode v = n.get(field);
        return v == null || v.isNull() ? null : v.asText();
    }

    private static String enc(String s) {
        return URLEncoder.encode(s == null ? "" : s, StandardCharsets.UTF_8);
    }
}
