package software.magizhchi.suite.chat;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import software.magizhchi.suite.SuiteException;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Chat through Magizhchi Box chat, which Magizhchi Messenger shows. Chat is never built inside another app: the
 * Magizhchi bar ({@code messenger.magizhchi.software/bar/magizhchi-bar.js}) shows it in every app's page.
 *
 * <p>Uses {@code magizhchi.box.url} (or the {@code MAGIZHCHI_BOX_URL} variable some apps already have), the
 * provision secret and {@code magizhchi.suite.app-name}.
 */
public class SuiteChat {

    /** A chat pass. {@code raw}: everything Box sent (pass, expiresAt, userId, name); hand it to the bar as is. */
    public record ChatPass(String pass, String expiresAt, Map<String, Object> raw) {}

    private final String boxUrl;
    private final String secret;
    private final String app;
    private final ObjectMapper mapper;
    private final HttpClient http;

    public SuiteChat(String boxUrl, String secret, String app, ObjectMapper mapper) {
        this(boxUrl, secret, app, mapper, HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build());
    }

    SuiteChat(String boxUrl, String secret, String app, ObjectMapper mapper, HttpClient http) {
        this.boxUrl = boxUrl == null ? "" : boxUrl.trim().replaceAll("/+$", "");
        this.secret = secret == null ? "" : secret.trim();
        this.app = app == null ? "" : app.trim();
        this.mapper = mapper;
        this.http = http;
    }

    /** True when Box's address, the provision secret and this app's name are all set. */
    public boolean configured() {
        return !boxUrl.isBlank() && !secret.isBlank() && !app.isBlank();
    }

    /**
     * A chat pass for the Magizhchi bar in this app, for the person signed in here: a short Box token (about an
     * hour) that opens Box chat only, never their files. The bar asks again before it runs out. Someone new to Box
     * gets their free Box account. Your endpoint must only ever hand a person their OWN pass.
     */
    public ChatPass chatPass(String accountId, String email, String name) {
        Map<String, Object> as = new LinkedHashMap<>();
        as.put("accountId", accountId);
        as.put("email", email);
        as.put("name", name);
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("as", as);
        body.put("app", app);
        JsonNode n = post("/api/provision/chat/pass", body);
        @SuppressWarnings("unchecked")
        Map<String, Object> raw = mapper.convertValue(n, Map.class);
        return new ChatPass(text(n, "pass"), text(n, "expiresAt"), Collections.unmodifiableMap(new LinkedHashMap<>(raw)));
    }

    // ───────────────────────── helpers ─────────────────────────

    private JsonNode post(String path, Object body) {
        if (!configured()) {
            throw SuiteException.notConfigured("Magizhchi Box chat (magizhchi.box.url, magizhchi.provision-secret, magizhchi.suite.app-name)");
        }
        HttpRequest req;
        try {
            req = HttpRequest.newBuilder(URI.create(boxUrl + path))
                    .timeout(Duration.ofSeconds(10))
                    .header("X-Provision-Secret", secret)
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(mapper.writeValueAsString(body)))
                    .build();
        } catch (IOException e) {
            throw new IllegalStateException(e);
        }
        HttpResponse<String> res;
        try {
            res = http.send(req, HttpResponse.BodyHandlers.ofString());
        } catch (IOException e) {
            throw new SuiteException(503, "box_unreachable", "Magizhchi Box can't be reached right now. Try again in a minute.");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new SuiteException(503, "interrupted", "Interrupted while calling Magizhchi Box.");
        }
        JsonNode n;
        try {
            n = res.body() == null || res.body().isBlank() ? mapper.createObjectNode() : mapper.readTree(res.body());
        } catch (IOException e) {
            n = mapper.createObjectNode();
        }
        int code = res.statusCode();
        if (code >= 300) {
            String msg = n.path("message").asText(n.path("error").asText("Magizhchi Box answered " + code + "."));
            boolean wrongSecret = code == 403 && msg.toLowerCase().contains("provisioning secret");
            throw new SuiteException(wrongSecret ? 503 : code, "box_" + code,
                    wrongSecret ? "This app's provision secret is wrong for Magizhchi Box (magizhchi.provision-secret)." : msg);
        }
        return n;
    }

    private static String text(JsonNode n, String field) {
        JsonNode v = n.get(field);
        return v == null || v.isNull() ? null : v.asText();
    }
}
