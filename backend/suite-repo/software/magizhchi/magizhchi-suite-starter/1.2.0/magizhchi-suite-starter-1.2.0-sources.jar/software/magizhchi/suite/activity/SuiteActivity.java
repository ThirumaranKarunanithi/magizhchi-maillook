package software.magizhchi.suite.activity;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Tells Magizhchi PA what happened in this app ({@code POST /api/v1/public/suite/activity}), so the owner sees it in
 * the one place they open. Events wait in a small in-memory queue and go in batches every few seconds, so a burst of
 * edits is one request and a slow or missing PA never slows the screen that caused the event. Does nothing until
 * the PA secret and {@code magizhchi.suite.app-id} are set.
 */
public class SuiteActivity implements AutoCloseable {

    private static final Logger log = LoggerFactory.getLogger(SuiteActivity.class);
    static final int MAX_QUEUE = 2000;
    static final int MAX_BATCH = 200;

    /** 1 routine, 2 notable, 3 needs the owner (PA also sends a notification). */
    public enum Importance {
        ROUTINE(1), NOTABLE(2), NEEDS_OWNER(3);

        final int value;

        Importance(int value) { this.value = value; }
    }

    /**
     * One thing that happened.
     *
     * @param key the same key twice stores one event, so a retry or a burst of autosaves is harmless
     */
    public record Event(String kind, String title, String detail, String actor, String link, Importance importance, String key) {}

    private record Pending(String ownerEmail, Map<String, Object> event) {}

    private final String appId;
    private final String paUrl;
    private final String secret;
    private final ObjectMapper mapper;
    private final HttpClient http;
    private final ConcurrentLinkedQueue<Pending> queue = new ConcurrentLinkedQueue<>();
    private final AtomicInteger size = new AtomicInteger();
    private final ScheduledExecutorService timer;

    public SuiteActivity(String appId, String paUrl, String secret, ObjectMapper mapper) {
        this(appId, paUrl, secret, mapper, HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build(), true);
    }

    SuiteActivity(String appId, String paUrl, String secret, ObjectMapper mapper, HttpClient http, boolean schedule) {
        this.appId = appId == null ? "" : appId.trim();
        this.paUrl = paUrl == null ? "" : paUrl.trim().replaceAll("/+$", "");
        this.secret = secret == null ? "" : secret.trim();
        this.mapper = mapper;
        this.http = http;
        if (enabled() && schedule) {
            this.timer = Executors.newSingleThreadScheduledExecutor(r -> {
                Thread t = new Thread(r, "suite-activity");
                t.setDaemon(true);
                return t;
            });
            timer.scheduleWithFixedDelay(this::flush, 4, 4, TimeUnit.SECONDS);
        } else {
            this.timer = null;
        }
    }

    public boolean enabled() {
        return !secret.isBlank() && !paUrl.isBlank() && !appId.isBlank();
    }

    /** Queues one event for the person who owns the thing it happened to. Never throws, never blocks. */
    public void report(String ownerEmail, Event e) {
        if (!enabled() || ownerEmail == null || ownerEmail.isBlank() || e == null || e.title() == null) return;
        if (size.get() >= MAX_QUEUE) return;
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("kind", e.kind());
        m.put("title", e.title());
        m.put("detail", e.detail());
        m.put("actor", e.actor());
        m.put("link", e.link());
        m.put("importance", (e.importance() == null ? Importance.ROUTINE : e.importance()).value);
        m.put("key", e.key());
        m.put("at", Instant.now().toString());
        queue.add(new Pending(ownerEmail.trim().toLowerCase(), m));
        size.incrementAndGet();
    }

    /** Sends what is queued, one request per owner. Called by the timer; tests call it directly. */
    public void flush() {
        try {
            Map<String, List<Map<String, Object>>> byOwner = new LinkedHashMap<>();
            Pending p;
            int n = 0;
            while (n < MAX_BATCH && (p = queue.poll()) != null) {
                size.decrementAndGet();
                byOwner.computeIfAbsent(p.ownerEmail(), k -> new ArrayList<>()).add(p.event());
                n++;
            }
            for (Map.Entry<String, List<Map<String, Object>>> e : byOwner.entrySet()) {
                Map<String, Object> body = new LinkedHashMap<>();
                body.put("app", appId);
                body.put("ownerEmail", e.getKey());
                body.put("events", e.getValue());
                HttpRequest req = HttpRequest.newBuilder(URI.create(paUrl + "/api/v1/public/suite/activity"))
                        .timeout(Duration.ofSeconds(8))
                        .header("Content-Type", "application/json")
                        .header("X-Provision-Secret", secret)
                        .POST(HttpRequest.BodyPublishers.ofString(mapper.writeValueAsString(body)))
                        .build();
                HttpResponse<Void> res = http.send(req, HttpResponse.BodyHandlers.discarding());
                if (res.statusCode() >= 300) log.warn("PA activity feed answered {} for {} events", res.statusCode(), e.getValue().size());
            }
        } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
        } catch (Exception ex) {
            // PA down or slow: these events are dropped. The activity feed is a convenience, never a record.
            log.warn("PA activity feed unreachable: {}", ex.toString());
        }
    }

    int queued() {
        return size.get();
    }

    @Override
    public void close() {
        if (timer != null) {
            timer.shutdown();
            flush();
        }
    }
}
