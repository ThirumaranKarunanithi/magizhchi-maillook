package software.magizhchi.suite.events;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Once the app is up, tells the events bus which event types to deliver here (all the {@link SuiteEventHandler}s'
 * types) and where ({@code <public url><suite path>/events}). Tries a few times in the background if PA is away.
 */
public class SuiteEventsSubscriber implements ApplicationListener<ApplicationReadyEvent> {

    private static final Logger log = LoggerFactory.getLogger(SuiteEventsSubscriber.class);
    private static final long[] PAUSES = {0, 10, 30, 120, 600};

    private final List<SuiteEventHandler> handlers;
    private final String appId;
    private final String paUrl;
    private final String secret;
    private final String url;
    private final HttpClient http;

    public SuiteEventsSubscriber(List<SuiteEventHandler> handlers, String appId, String paUrl, String secret, String eventsUrl) {
        this(handlers, appId, paUrl, secret, eventsUrl,
                HttpClient.newBuilder().version(HttpClient.Version.HTTP_1_1).connectTimeout(Duration.ofSeconds(5)).build());
    }

    SuiteEventsSubscriber(List<SuiteEventHandler> handlers, String appId, String paUrl, String secret, String eventsUrl, HttpClient http) {
        this.handlers = List.copyOf(handlers);
        this.appId = appId == null ? "" : appId.trim();
        this.paUrl = paUrl == null ? "" : paUrl.trim().replaceAll("/+$", "");
        this.secret = secret == null ? "" : secret.trim();
        this.url = eventsUrl == null ? "" : eventsUrl.trim();
        this.http = http;
    }

    /** Every handler's types, once each. */
    List<String> types() {
        List<String> out = new ArrayList<>();
        for (SuiteEventHandler h : handlers) {
            if (h.types() == null) continue;
            for (String t : h.types()) {
                if (t != null && !t.isBlank() && !out.contains(t.trim())) out.add(t.trim());
            }
        }
        return out;
    }

    @Override
    public void onApplicationEvent(ApplicationReadyEvent event) {
        if (appId.isBlank() || secret.isBlank() || paUrl.isBlank()) {
            log.warn("Events bus: this app has event handlers, but magizhchi.suite.app-id or the suite secret is not set, so it won't receive events.");
            return;
        }
        if (url.isBlank()) {
            log.warn("Events bus: set magizhchi.suite.public-url (this app's https address) so the bus knows where to deliver events.");
            return;
        }
        Thread t = new Thread(this::subscribeWithRetries, "suite-events-subscribe");
        t.setDaemon(true);
        t.start();
    }

    void subscribeWithRetries() {
        for (long pause : PAUSES) {
            try {
                if (pause > 0) Thread.sleep(pause * 1000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            }
            int status = subscribe();
            if (status / 100 == 2) {
                log.info("Events bus: {} subscribed to {}", appId, types());
                return;
            }
            if (status == 400) return;   // a wrong setting; trying again won't help (the reason is logged)
        }
        log.warn("Events bus: could not subscribe {} (PA unreachable); events wait at PA until it does", appId);
    }

    /** One attempt; the HTTP status, or 0 when PA could not be reached. */
    int subscribe() {
        try {
            Map<String, Object> body = new LinkedHashMap<>();
            body.put("app", appId);
            body.put("url", url);
            body.put("types", types());
            HttpRequest req = HttpRequest.newBuilder(URI.create(paUrl + "/api/v1/public/suite/events/subscription"))
                    .timeout(Duration.ofSeconds(10))
                    .header("Content-Type", "application/json")
                    .header("X-Provision-Secret", secret)
                    .PUT(HttpRequest.BodyPublishers.ofString(new ObjectMapper().writeValueAsString(body)))
                    .build();
            HttpResponse<String> res = http.send(req, HttpResponse.BodyHandlers.ofString());
            if (res.statusCode() == 400) log.error("Events bus refused the subscription: {}", res.body());
            return res.statusCode();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return 0;
        } catch (Exception e) {
            log.debug("Events bus subscribe failed: {}", e.toString());
            return 0;
        }
    }
}
