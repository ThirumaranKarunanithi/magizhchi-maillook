package software.magizhchi.suite.auth;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import software.magizhchi.suite.SuiteException;

import javax.crypto.Mac;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Set;

/**
 * Checks a Magizhchi ID delegation token (Suite Brain protocol v1). The key is
 * {@code HMAC-SHA256(secret, "magizhchi-suite-delegation|" + appName)}, so the token cannot sign anyone in and a
 * token minted for another product fails here. Also checks {@code act == "Magizhchi PA"}, that {@code aud} names
 * this app, and expiry.
 */
public class DelegationVerifier {

    public static final String ACTOR = "Magizhchi PA";

    private final String appName;
    private final SecretKey key;

    public DelegationVerifier(String secret, String appName) {
        this.appName = appName == null ? "" : appName.trim();
        this.key = secret == null || secret.isBlank() || this.appName.isEmpty() ? null
                : deriveKey(secret.getBytes(StandardCharsets.UTF_8), this.appName);
    }

    /** The derived signing key, exactly as Magizhchi ID's JwtService.delegationKey derives it. */
    public static SecretKey deriveKey(byte[] secretBytes, String audience) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(secretBytes, "HmacSHA256"));
            return Keys.hmacShaKeyFor(mac.doFinal(("magizhchi-suite-delegation|" + audience).getBytes(StandardCharsets.UTF_8)));
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException(e);
        }
    }

    public String appName() {
        return appName;
    }

    public Delegation verify(String token) {
        if (key == null) throw SuiteException.notConfigured("Suite access");
        if (token == null || token.isBlank()) throw SuiteException.unauthorized("Missing bearer token.");
        Claims c;
        try {
            c = Jwts.parser().verifyWith(key).build().parseSignedClaims(token.trim()).getPayload();
        } catch (Exception e) {
            throw SuiteException.unauthorized("Invalid delegation token.");
        }
        if (!ACTOR.equals(c.get("act", String.class)) || c.getAudience() == null || !c.getAudience().contains(appName)) {
            throw SuiteException.unauthorized("Token is not for this product.");
        }
        String email = c.get("email", String.class);
        if (email == null || email.isBlank()) throw SuiteException.unauthorized("Token has no email.");
        String scope = c.get("scope", String.class);
        Set<String> scopes = scope == null || scope.isBlank() ? Set.of()
                : Set.copyOf(new LinkedHashSet<>(Arrays.asList(scope.trim().split("\\s+"))));
        return new Delegation(c.getSubject(), email.trim().toLowerCase(), scopes, c.getId());
    }

    /** Reads {@code Authorization: Bearer ...} and verifies it. */
    public Delegation verifyHeader(String authorization) {
        if (authorization == null || !authorization.regionMatches(true, 0, "Bearer ", 0, 7)) {
            throw SuiteException.unauthorized("Missing bearer token.");
        }
        return verify(authorization.substring(7));
    }
}
