package software.magizhchi.suite.pay;

import java.time.Instant;

/**
 * What this app does when Magizhchi ID says something was paid for: a {@link SuitePay} payment, or this app's part
 * of a Magizhchi Suite bundle. Declare one bean and the library answers ID's {@code POST <suite path>/activate}.
 *
 * <p>ID may call more than once for the same purchase (retries, browser and webhook both reporting). Deliver once per
 * {@link Purchase#orderRef()} and answer {@link Delivery#done} again for a repeat.
 */
public interface SuitePurchases {

    /**
     * One paid purchase.
     *
     * @param orderRef    unique per purchase: de-duplicate on this
     * @param email       who paid (their Magizhchi ID email)
     * @param planCode    this app's own code for what was bought (plan, pack or item)
     * @param cycle       MONTHLY or YEARLY for a plan, else null
     * @param amountPaise what this app's part cost, GST included
     * @param payId       the Magizhchi Pay payment id, or null for a Suite bundle
     * @param reference   the reference this app gave when it started the payment, or null for a Suite bundle
     * @param label       what the person saw, or null
     * @param kind        PLAN, CREDITS or ONE_OFF (null for a Suite bundle, which is always a plan)
     */
    record Purchase(String orderRef, String email, String planCode, String cycle, long amountPaise,
                    String payId, String reference, String label, String kind) {
        public boolean fromSuiteBundle() { return payId == null; }
    }

    /** The answer for ID. */
    record Delivery(String status, Instant endsAt, String message) {
        /** Applied (or already applied before). {@code endsAt}: when a plan runs out, else null. */
        public static Delivery done(Instant endsAt) { return new Delivery("DONE", endsAt, null); }
        public static Delivery done() { return done(null); }
        /** This app has no account for that email yet; ID retries hourly until there is one. */
        public static Delivery noAccount() { return new Delivery("NO_ACCOUNT", null, null); }
        /** Something went wrong; ID retries with a growing pause, and shows the message to the person. */
        public static Delivery failed(String message) { return new Delivery("ERROR", null, message); }
    }

    Delivery deliver(Purchase purchase);
}
