package software.magizhchi.suite;

/**
 * A refusal with an HTTP status and a sentence a person can read. Apps can map it in their own exception
 * handler; the Suite Brain endpoints turn it into {@code {"error": "..."}} themselves.
 */
public class SuiteException extends RuntimeException {

    private final int status;
    private final String code;

    public SuiteException(int status, String code, String message) {
        super(message);
        this.status = status;
        this.code = code;
    }

    public int status() { return status; }
    public String code() { return code; }

    public static SuiteException unauthorized(String message) { return new SuiteException(401, "unauthorized", message); }
    public static SuiteException forbidden(String message) { return new SuiteException(403, "forbidden", message); }
    public static SuiteException notFound(String message) { return new SuiteException(404, "not_found", message); }
    public static SuiteException badRequest(String message) { return new SuiteException(400, "bad_request", message); }
    public static SuiteException notConfigured(String what) {
        return new SuiteException(503, "not_configured", what + " is not configured on this server.");
    }
}
