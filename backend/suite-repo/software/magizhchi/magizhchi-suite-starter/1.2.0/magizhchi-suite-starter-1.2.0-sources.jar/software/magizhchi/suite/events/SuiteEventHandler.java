package software.magizhchi.suite.events;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Reacts to other apps' events on the suite's events bus. Declare one as a bean and the library subscribes this app
 * to its {@link #types()} when it starts, and calls {@link #handle} for each event that arrives.
 *
 * <pre>
 * &#64;Component
 * class LeadFromForm implements SuiteEventHandler {
 *     public List&lt;String&gt; types() { return List.of("forms.form.submitted"); }
 *     public void handle(Event e) {
 *         leads.createFromForm(e.ownerEmail(), e.data());        // must be safe to run twice for one event
 *     }
 * }
 * </pre>
 *
 * Delivery is at least once: throwing makes the bus send the event again later (for up to 3 days), so make
 * {@code handle} idempotent, for example by remembering {@link Event#id()} or the source's {@link Event#key()}.
 */
public interface SuiteEventHandler {

    /** Exact types ({@code forms.form.submitted}) or every type of one app ({@code forms.*}). */
    List<String> types();

    void handle(Event event) throws Exception;

    /**
     * One event as the bus delivers it.
     *
     * @param id    the bus's id for it, the same on every retry
     * @param app   the app that published it
     * @param key   the publishing app's own id for it (e.g. the form response id)
     * @param data  what the publisher sent; never null
     */
    record Event(String id, String app, String type, String key, String ownerEmail, UUID orgId, Instant occurredAt,
                 Map<String, Object> data) {

        /** A value from {@link #data()} as text, or null. */
        public String text(String field) {
            Object v = data == null ? null : data.get(field);
            return v == null ? null : String.valueOf(v);
        }
    }
}
