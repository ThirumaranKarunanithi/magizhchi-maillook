package software.magizhchi.suite.auth;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import software.magizhchi.suite.SuiteException;
import software.magizhchi.suite.SuiteProperties;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Date;
import java.util.Optional;
import java.util.UUID;

/**
 * Magizhchi ID sign-in tokens: HS256, signed with the raw UTF-8 bytes of {@code magizhchi.jwt.secret}, exactly as
 * Magizhchi ID signs them. Replaces the {@code MagizhchiTokenVerifier} each app copied, plus the token minting that
 * apps do to call each other (PA chat, CRM to Forms, Meet to CRM...), so every minted token carries the issuer.
 */
public class SuiteTokens {

    private final SecretKey key;
    private final String issuer;
    private final boolean requireIssuer;

    public SuiteTokens(SuiteProperties props) {
        this(props.getJwt().getSecret(), props.getJwt().getIssuer(), props.getJwt().isRequireIssuer());
    }

    public SuiteTokens(String secret, String issuer, boolean requireIssuer) {
        // Keys.hmacShaKeyFor refuses a secret under 32 bytes, the same rule Magizhchi ID applies.
        this.key = secret == null || secret.isBlank() ? null : Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));
        this.issuer = issuer == null || issuer.isBlank() ? "magizhchi-id" : issuer;
        this.requireIssuer = requireIssuer;
    }

    public boolean configured() {
        return key != null;
    }

    /** The person a Magizhchi ID token names. Throws 401 with a readable reason when it is not valid. */
    public SuiteIdentity verify(String token) {
        if (key == null) throw SuiteException.notConfigured("Magizhchi ID sign-in");
        if (token == null || token.isBlank()) throw SuiteException.unauthorized("No Magizhchi ID token.");
        Claims c;
        try {
            c = Jwts.parser().verifyWith(key).build().parseSignedClaims(token.trim()).getPayload();
        } catch (Exception e) {
            throw SuiteException.unauthorized("Invalid or expired Magizhchi ID token.");
        }
        if (requireIssuer && !issuer.equals(c.getIssuer())) throw SuiteException.unauthorized("Token was not issued by Magizhchi ID.");
        String email = c.get("email", String.class);
        if (email == null || email.isBlank()) throw SuiteException.unauthorized("Token has no email.");
        String name = c.get("name", String.class);
        return new SuiteIdentity(c.getSubject(), email.trim().toLowerCase(), name == null || name.isBlank() ? null : name.trim());
    }

    /** Like {@link #verify} but empty instead of throwing, for filters that try several kinds of token. */
    public Optional<SuiteIdentity> tryVerify(String token) {
        try {
            return Optional.of(verify(token));
        } catch (SuiteException e) {
            return Optional.empty();
        }
    }

    /**
     * A short-lived Magizhchi ID token for this person, for calling another suite app on their behalf (PA's chat,
     * another app's sign-in exchange). Keep {@code ttl} short: minutes, not days.
     */
    public String mint(String accountId, String email, String name, Duration ttl) {
        if (key == null) throw SuiteException.notConfigured("Magizhchi ID sign-in");
        if (email == null || email.isBlank()) throw new IllegalArgumentException("email is required");
        Date now = new Date();
        return Jwts.builder()
                .issuer(issuer)
                .subject(accountId == null || accountId.isBlank() ? email.trim().toLowerCase() : accountId)
                .claim("email", email.trim().toLowerCase())
                .claim("name", name == null ? "" : name)
                .id(UUID.randomUUID().toString())
                .issuedAt(now)
                .expiration(new Date(now.getTime() + ttl.toMillis()))
                .signWith(key)
                .compact();
    }
}
