package software.magizhchi.suite.provider;

/**
 * Magizhchi Provider refused a message or could not be reached.
 *
 * @see #retryable() true for network trouble, 429 and 5xx: try again later or fall back to the old sender
 */
public class ProviderException extends RuntimeException {

    private final int status;
    private final String code;
    private final boolean retryable;

    public ProviderException(int status, String code, String message, boolean retryable) {
        super(message);
        this.status = status;
        this.code = code;
        this.retryable = retryable;
    }

    /** The HTTP status, or 0 when Provider was not reached. */
    public int status() { return status; }

    /** Provider's error code, e.g. {@code insufficient_balance}, {@code sender_not_verified}, {@code recipient_suppressed}. */
    public String code() { return code; }

    public boolean retryable() { return retryable; }
}
