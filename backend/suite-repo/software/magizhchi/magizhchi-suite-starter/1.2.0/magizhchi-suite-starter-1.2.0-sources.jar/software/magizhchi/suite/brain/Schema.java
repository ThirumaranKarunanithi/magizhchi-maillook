package software.magizhchi.suite.brain;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Small builder for tool input schemas, so a tool reads
 * {@code Schema.object().string("company", "Company name.", true).integer("days", "How many days back.", false).build()}.
 */
public final class Schema {

    private final Map<String, Object> properties = new LinkedHashMap<>();
    private final List<String> required = new ArrayList<>();

    private Schema() {}

    public static Schema object() {
        return new Schema();
    }

    public Schema string(String name, String description, boolean required) {
        return prop(name, Map.of("type", "string", "description", description), required);
    }

    public Schema integer(String name, String description, boolean required) {
        return prop(name, Map.of("type", "integer", "description", description), required);
    }

    public Schema number(String name, String description, boolean required) {
        return prop(name, Map.of("type", "number", "description", description), required);
    }

    public Schema bool(String name, String description, boolean required) {
        return prop(name, Map.of("type", "boolean", "description", description), required);
    }

    public Schema strings(String name, String description, boolean required) {
        return prop(name, Map.of("type", "array", "items", Map.of("type", "string"), "description", description), required);
    }

    public Schema oneOf(String name, String description, List<String> values, boolean required) {
        return prop(name, Map.of("type", "string", "enum", List.copyOf(values), "description", description), required);
    }

    /** Any JSON Schema fragment, for shapes the helpers above don't cover. */
    public Schema prop(String name, Map<String, Object> schema, boolean required) {
        properties.put(name, schema);
        if (required) this.required.add(name);
        return this;
    }

    public Map<String, Object> build() {
        Map<String, Object> s = new LinkedHashMap<>();
        s.put("type", "object");
        s.put("properties", new LinkedHashMap<>(properties));
        s.put("required", List.copyOf(required));
        return s;
    }

    // ---- reading input -------------------------------------------------------------------------

    /** A trimmed string, or null when missing or blank. */
    public static String text(Map<String, Object> input, String key) {
        Object v = input == null ? null : input.get(key);
        if (v == null) return null;
        String s = v.toString().trim();
        return s.isEmpty() ? null : s;
    }

    /** A trimmed string that must be there. */
    public static String requireText(Map<String, Object> input, String key) {
        String s = text(input, key);
        if (s == null) throw new IllegalArgumentException(key + " is required.");
        return s;
    }

    /** A whole number, the default when missing, clamped to [min, max]. */
    public static int integer(Map<String, Object> input, String key, int dflt, int min, int max) {
        Object v = input == null ? null : input.get(key);
        int n;
        if (v instanceof Number num) n = num.intValue();
        else if (v != null && !v.toString().isBlank()) {
            try {
                n = Integer.parseInt(v.toString().trim());
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException(key + " must be a whole number.");
            }
        } else n = dflt;
        return Math.max(min, Math.min(max, n));
    }

    /** A list of non-blank strings; a single string counts as a list of one. */
    public static List<String> texts(Map<String, Object> input, String key) {
        Object v = input == null ? null : input.get(key);
        List<String> out = new ArrayList<>();
        if (v instanceof Iterable<?> it) {
            for (Object o : it) if (o != null && !o.toString().isBlank()) out.add(o.toString().trim());
        } else if (v != null && !v.toString().isBlank()) {
            out.add(v.toString().trim());
        }
        return out;
    }
}
