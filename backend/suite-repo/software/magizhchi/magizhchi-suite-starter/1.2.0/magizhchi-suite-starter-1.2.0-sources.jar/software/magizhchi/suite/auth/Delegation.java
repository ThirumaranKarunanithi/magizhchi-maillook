package software.magizhchi.suite.auth;

import java.util.Set;

/**
 * Magizhchi PA acting for one person in this app, as Magizhchi ID allowed it.
 *
 * @param accountId the person's Magizhchi ID account id
 * @param email     lower-cased
 * @param scopes    {@code read}, or {@code read write}
 * @param tokenId   the token's {@code jti}, matching Magizhchi ID's DELEGATION_ISSUED audit entry
 */
public record Delegation(String accountId, String email, Set<String> scopes, String tokenId) {

    public boolean canWrite() {
        return scopes.contains("write");
    }
}
