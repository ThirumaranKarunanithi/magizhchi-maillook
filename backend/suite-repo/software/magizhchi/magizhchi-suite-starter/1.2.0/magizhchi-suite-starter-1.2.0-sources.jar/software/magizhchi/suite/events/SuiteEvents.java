package software.magizhchi.suite.events;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

/**
 * Publishes this app's events to the suite's events bus in Magizhchi PA ({@code POST /api/v1/public/suite/events}),
 * where other apps and the owner's "when this happens" automations pick them up.
 *
 * <pre>
 * events.publish(SuiteEvents.Event.of("crm.lead.created", lead.getId().toString())
 *         .owner(owner.getEmail())
 *         .data(Map.of("leadId", lead.getId(), "name", lead.getName(), "phone", lead.getPhone()))
 *         .title("New lead: " + lead.getName()));     // a title also puts it in the owner's activity feed
 * </pre>
 *
 * Events wait in memory and go in batches every couple of seconds, so publishing never slows the request that caused
 * it. If PA can't be reached they stay queued and are tried again (oldest first, up to {@value #MAX_QUEUE} events);
 * the same id published twice is stored once, so a retry is harmless. Does nothing until {@code magizhchi.suite.app-id}
 * and the PA secret are set.
 */
public class SuiteEvents implements AutoCloseable {

    private static final Logger log = LoggerFactory.getLogger(SuiteEvents.class);
    static final int MAX_QUEUE = 5000;
    static final int MAX_BATCH = 100;
    private static final Pattern TYPE = Pattern.compile("[a-z][a-z0-9]*(\\.[a-z][a-z0-9_]*){2,3}");

    /** One event. {@code id} is this app's own id for it (e.g. the lead's id), so publishing it twice stores it once. */
    public static final class Event {
        final String type;
        final String id;
        String ownerEmail;
        UUID orgId;
        Instant occurredAt = Instant.now();
        Map<String, Object> data;
        String title;
        String detail;
        String actor;
        String link;
        Integer importance;

        private Event(String type, String id) {
            this.type = type;
            this.id = id;
        }

        public static Event of(String type, String id) {
            return new Event(type, id);
        }

        /** The person the event is about or belongs to (their automations run, and it shows in their feed). */
        public Event owner(String email) { this.ownerEmail = email; return this; }
        public Event org(UUID orgId) { this.orgId = orgId; return this; }
        public Event at(Instant when) { this.occurredAt = when; return this; }
        /** Small facts receivers need (ids, names, amounts); at most 16 KB as JSON. Receivers fetch anything bigger. */
        public Event data(Map<String, Object> data) { this.data = data; return this; }
        /** A line for the owner's activity feed; without one the event is not shown there. */
        public Event title(String title) { this.title = title; return this; }
        public Event detail(String detail) { this.detail = detail; return this; }
        public Event actor(String actor) { this.actor = actor; return this; }
        public Event link(String link) { this.link = link; return this; }
        /** 1 routine, 2 notable, 3 needs the owner (PA also sends a notification). */
        public Event importance(int importance) { this.importance = importance; return this; }
    }

    private final String appId;
    private final String paUrl;
    private final String secret;
    // A plain mapper (the bus's wire format is fixed, whatever the app's own JSON settings), dates as ISO text.
    private final ObjectMapper mapper = new ObjectMapper().findAndRegisterModules()
            .disable(com.fasterxml.jackson.databind.SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
    private final HttpClient http;
    private final LinkedBlockingDeque<Map<String, Object>> queue = new LinkedBlockingDeque<>(MAX_QUEUE);
    private final ScheduledExecutorService timer;
    private volatile Instant pauseUntil = Instant.EPOCH;
    private int failures;

    public SuiteEvents(String appId, String paUrl, String secret) {
        this(appId, paUrl, secret, HttpClient.newBuilder().version(HttpClient.Version.HTTP_1_1).connectTimeout(Duration.ofSeconds(5)).build(), true);
    }

    SuiteEvents(String appId, String paUrl, String secret, HttpClient http, boolean schedule) {
        this.appId = appId == null ? "" : appId.trim();
        this.paUrl = paUrl == null ? "" : paUrl.trim().replaceAll("/+$", "");
        this.secret = secret == null ? "" : secret.trim();
        this.http = http;
        if (enabled() && schedule) {
            this.timer = Executors.newSingleThreadScheduledExecutor(r -> {
                Thread t = new Thread(r, "suite-events");
                t.setDaemon(true);
                return t;
            });
            timer.scheduleWithFixedDelay(this::flush, 2, 2, TimeUnit.SECONDS);
        } else {
            this.timer = null;
        }
    }

    public boolean enabled() {
        return !secret.isBlank() && !paUrl.isBlank() && !appId.isBlank();
    }

    public String appId() {
        return appId;
    }

    /**
     * Queues an event. Never blocks and never fails because PA is away. Throws {@link IllegalArgumentException} only
     * for a programming mistake: a type that isn't {@code <this app id>.<thing>.<what happened>}, or no id.
     */
    public void publish(Event e) {
        if (e == null) return;
        if (!enabled()) return;
        if (e.type == null || !TYPE.matcher(e.type).matches() || !e.type.startsWith(appId + ".")) {
            throw new IllegalArgumentException("Event type \"" + e.type + "\" must look like " + appId + ".lead.created");
        }
        if (e.id == null || e.id.isBlank() || e.id.length() > 120) {
            throw new IllegalArgumentException("An event needs this app's own id for it (up to 120 characters).");
        }
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", e.id.trim());
        m.put("type", e.type);
        m.put("ownerEmail", e.ownerEmail == null || e.ownerEmail.isBlank() ? null : e.ownerEmail.trim().toLowerCase());
        m.put("orgId", e.orgId == null ? null : e.orgId.toString());
        m.put("occurredAt", (e.occurredAt == null ? Instant.now() : e.occurredAt).toString());
        m.put("data", e.data);
        m.put("title", e.title);
        m.put("detail", e.detail);
        m.put("actor", e.actor);
        m.put("link", e.link);
        m.put("importance", e.importance);
        if (!queue.offerLast(m)) log.warn("Events bus queue is full ({} waiting); dropped {} {}", MAX_QUEUE, e.type, e.id);
    }

    /** Sends what is queued. Called by the timer every 2 seconds; tests call it directly. */
    public synchronized void flush() {
        if (!enabled() || queue.isEmpty() || Instant.now().isBefore(pauseUntil)) return;
        while (!queue.isEmpty()) {
            List<Map<String, Object>> batch = new ArrayList<>();
            Map<String, Object> next;
            while (batch.size() < MAX_BATCH && (next = queue.pollFirst()) != null) batch.add(next);
            int status = send(batch);
            if (status / 100 == 2) {
                failures = 0;
                continue;
            }
            if (status == 400 || status == 413) {
                // PA refused the batch as wrong: sending it again would fail again. A bug in this app, so say so loudly.
                log.error("The events bus refused {} event(s) from {} (HTTP {}); they are dropped", batch.size(), appId, status);
                continue;
            }
            // PA away, or not allowed (wrong secret): keep them, oldest first, and wait a little longer each time.
            for (int i = batch.size() - 1; i >= 0; i--) {
                if (!queue.offerFirst(batch.get(i))) break;
            }
            failures++;
            long seconds = Math.min(300, 5L << Math.min(failures - 1, 6));
            pauseUntil = Instant.now().plusSeconds(seconds);
            log.warn("Events bus unreachable or refused (HTTP {}); {} event(s) wait, next try in {}s", status, queue.size(), seconds);
            return;
        }
    }

    /** The HTTP status, or 0 when PA could not be reached. */
    private int send(List<Map<String, Object>> batch) {
        try {
            String body = mapper.writeValueAsString(Map.of("app", appId, "events", batch));
            HttpRequest req = HttpRequest.newBuilder(URI.create(paUrl + "/api/v1/public/suite/events"))
                    .timeout(Duration.ofSeconds(10))
                    .header("Content-Type", "application/json")
                    .header("X-Provision-Secret", secret)
                    .POST(HttpRequest.BodyPublishers.ofString(body))
                    .build();
            HttpResponse<String> res = http.send(req, HttpResponse.BodyHandlers.ofString());
            if (res.statusCode() == 400) log.error("Events bus said: {}", res.body());
            return res.statusCode();
        } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
            return 0;
        } catch (Exception ex) {
            log.debug("Events bus send failed: {}", ex.toString());
            return 0;
        }
    }

    int queued() {
        return queue.size();
    }

    /** Tests: end the pause after a failure. */
    void retryNow() {
        pauseUntil = Instant.EPOCH;
    }

    @Override
    public void close() {
        if (timer != null) {
            timer.shutdown();
            pauseUntil = Instant.EPOCH;
            flush();
        }
    }
}
