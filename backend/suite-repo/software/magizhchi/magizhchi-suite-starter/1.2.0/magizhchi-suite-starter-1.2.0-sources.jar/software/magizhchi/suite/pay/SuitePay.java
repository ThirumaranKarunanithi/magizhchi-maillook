package software.magizhchi.suite.pay;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import software.magizhchi.suite.SuiteException;

import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Magizhchi Pay for this app: take a payment through Magizhchi ID's one Razorpay checkout. The app never holds
 * payment keys and never trusts a browser for the amount.
 *
 * <pre>{@code
 * Payment p = pay.start(SuitePay.Order.plan("sub-" + companyId + "-2026-11", user.email(), "PRO", "Books Pro · yearly", "YEARLY", 1_180_00)
 *         .returnTo("https://books.magizhchi.software/billing"));
 * return redirect(p.checkoutUrl());
 * }</pre>
 *
 * Once paid, ID calls this app's {@code <suite path>/activate}; declare a {@link SuitePurchases} bean and the library
 * answers that call. The same {@code reference} always means the same payment, so retrying {@code start} is safe.
 */
public class SuitePay {

    /** What to charge for. Build with {@link #plan}, {@link #credits} or {@link #oneOff}. Amounts include GST. */
    public static final class Order {
        final String reference, email, itemCode, label, kind, cycle;
        final long amountPaise;
        String returnUrl;
        Integer expiresInMinutes;

        private Order(String reference, String email, String itemCode, String label, String kind, String cycle, long amountPaise) {
            this.reference = reference;
            this.email = email;
            this.itemCode = itemCode;
            this.label = label;
            this.kind = kind;
            this.cycle = cycle;
            this.amountPaise = amountPaise;
        }

        /** A plan for a period; {@code cycle} is MONTHLY or YEARLY. */
        public static Order plan(String reference, String email, String planCode, String label, String cycle, long amountPaise) {
            return new Order(reference, email, planCode, label, "PLAN", cycle, amountPaise);
        }

        /** Prepaid credits, points or a wallet top-up. */
        public static Order credits(String reference, String email, String packCode, String label, long amountPaise) {
            return new Order(reference, email, packCode, label, "CREDITS", null, amountPaise);
        }

        /** Anything else bought once. */
        public static Order oneOff(String reference, String email, String itemCode, String label, long amountPaise) {
            return new Order(reference, email, itemCode, label, "ONE_OFF", null, amountPaise);
        }

        /** Where the person lands after paying (an https address on magizhchi.software). */
        public Order returnTo(String url) {
            this.returnUrl = url;
            return this;
        }

        /** How long the payment link stays open (10 minutes to 7 days; default 24 hours). */
        public Order expiresIn(Duration d) {
            this.expiresInMinutes = (int) d.toMinutes();
            return this;
        }
    }

    /**
     * A payment as ID sees it. {@code status}: OPEN (waiting), PAID (paid, being delivered), DELIVERED (this app
     * applied it), NEEDS_ATTENTION (paid, delivery still retrying), EXPIRED or CANCELLED.
     */
    public record Payment(String id, String reference, String status, long amountPaise, String checkoutUrl, String receiptNo,
                          Instant expiresAt, Instant paidAt, Instant deliveredAt, Instant endsAt, String lastError) {
        public boolean open() { return "OPEN".equals(status); }
        public boolean paid() { return paidAt != null; }
    }

    private final String idUrl;
    private final String secret;
    private final String app;
    private final String notifyUrl;
    private final ObjectMapper mapper;
    private final HttpClient http;

    public SuitePay(String idUrl, String secret, String app, String notifyUrl, ObjectMapper mapper) {
        this(idUrl, secret, app, notifyUrl, mapper, HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build());
    }

    SuitePay(String idUrl, String secret, String app, String notifyUrl, ObjectMapper mapper, HttpClient http) {
        this.idUrl = idUrl == null ? "" : idUrl.trim().replaceAll("/+$", "");
        this.secret = secret == null ? "" : secret.trim();
        this.app = app == null ? "" : app.trim();
        this.notifyUrl = notifyUrl == null ? "" : notifyUrl.trim();
        this.mapper = mapper;
        this.http = http;
    }

    /** True when ID's address, the provision secret, this app's name and its public address are all known. */
    public boolean configured() {
        return !idUrl.isBlank() && !secret.isBlank() && !app.isBlank() && !notifyUrl.isBlank();
    }

    /** Start (or, with the same reference, find again) a payment. Send the person to {@link Payment#checkoutUrl()}. */
    public Payment start(Order o) {
        requireConfigured();
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("app", app);
        body.put("reference", o.reference);
        body.put("email", o.email);
        body.put("itemCode", o.itemCode);
        body.put("label", o.label);
        body.put("kind", o.kind);
        body.put("cycle", o.cycle);
        body.put("amountPaise", o.amountPaise);
        body.put("notifyUrl", notifyUrl);
        body.put("returnUrl", o.returnUrl);
        body.put("expiresInMinutes", o.expiresInMinutes);
        String json;
        try {
            json = mapper.writeValueAsString(body);
        } catch (IOException e) {
            throw new IllegalStateException(e);
        }
        return payment(send(HttpRequest.newBuilder(URI.create(idUrl + "/api/v1/provision/pay"))
                .timeout(Duration.ofSeconds(15))
                .header("Content-Type", "application/json")
                .header("X-Provision-Secret", secret)
                .POST(HttpRequest.BodyPublishers.ofString(json)).build()));
    }

    /** Where a payment stands (for a page the person returns to, or a check before giving up on it). */
    public Payment status(String id) {
        requireConfigured();
        return payment(send(HttpRequest.newBuilder(URI.create(idUrl + "/api/v1/provision/pay/" + enc(id) + "?app=" + enc(app)))
                .timeout(Duration.ofSeconds(10))
                .header("X-Provision-Secret", secret)
                .GET().build()));
    }

    /** Withdraw a payment nobody has paid. A paid one can't be cancelled (ID answers 409). */
    public Payment cancel(String id) {
        requireConfigured();
        return payment(send(HttpRequest.newBuilder(URI.create(idUrl + "/api/v1/provision/pay/" + enc(id) + "/cancel?app=" + enc(app)))
                .timeout(Duration.ofSeconds(10))
                .header("X-Provision-Secret", secret)
                .POST(HttpRequest.BodyPublishers.noBody()).build()));
    }

    private Payment payment(JsonNode n) {
        return new Payment(text(n, "id"), text(n, "reference"), text(n, "status"), n.path("amountPaise").asLong(),
                text(n, "checkoutUrl"), text(n, "receiptNo"), time(n, "expiresAt"), time(n, "paidAt"),
                time(n, "deliveredAt"), time(n, "endsAt"), text(n, "lastError"));
    }

    private JsonNode send(HttpRequest req) {
        HttpResponse<String> res;
        try {
            res = http.send(req, HttpResponse.BodyHandlers.ofString());
        } catch (IOException e) {
            throw new SuiteException(503, "id_unreachable", "Payments are unavailable right now (Magizhchi ID can't be reached). Try again in a minute.");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new SuiteException(503, "interrupted", "Interrupted while calling Magizhchi ID.");
        }
        JsonNode n;
        try {
            n = res.body() == null || res.body().isBlank() ? mapper.createObjectNode() : mapper.readTree(res.body());
        } catch (IOException e) {
            n = mapper.createObjectNode();
        }
        if (res.statusCode() >= 300) {
            String msg = n.path("message").asText(n.path("error").asText("Magizhchi ID answered " + res.statusCode() + "."));
            throw new SuiteException(res.statusCode() == 403 ? 503 : res.statusCode(), "pay_" + res.statusCode(),
                    res.statusCode() == 403 ? "This app's Magizhchi ID secret is wrong (magizhchi.provision-secret)." : msg);
        }
        return n;
    }

    private void requireConfigured() {
        if (!configured()) {
            throw SuiteException.notConfigured("Magizhchi Pay (magizhchi.id.url, magizhchi.provision-secret, magizhchi.suite.app-name, "
                    + "and magizhchi.suite.public-url or Railway's public domain)");
        }
    }

    private static String text(JsonNode n, String field) {
        JsonNode v = n.get(field);
        return v == null || v.isNull() ? null : v.asText();
    }

    private static Instant time(JsonNode n, String field) {
        String t = text(n, field);
        return t == null || t.isBlank() ? null : Instant.parse(t);
    }

    private static String enc(String s) {
        return URLEncoder.encode(s == null ? "" : s, StandardCharsets.UTF_8);
    }
}
