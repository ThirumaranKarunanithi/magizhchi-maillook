package software.magizhchi.suite.auth;

/**
 * Who a Magizhchi ID token names.
 *
 * @param accountId the Magizhchi ID account id ({@code sub}); store it as the app's {@code magizhchi_account_id}
 * @param email     lower-cased and trimmed
 * @param name      display name, or null when the person has none
 */
public record SuiteIdentity(String accountId, String email, String name) {}
