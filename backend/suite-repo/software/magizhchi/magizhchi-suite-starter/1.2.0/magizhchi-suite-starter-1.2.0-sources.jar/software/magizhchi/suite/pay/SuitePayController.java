package software.magizhchi.suite.pay;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import software.magizhchi.suite.SuiteException;
import software.magizhchi.suite.auth.SharedSecret;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Answers Magizhchi ID's "it is paid, deliver it" call: {@code POST <suite path>/activate} with
 * {@code X-Provision-Secret}. The same call ID already makes for the Suite bundle, so one handler serves both.
 */
@Controller
@ResponseBody
@RequestMapping("${magizhchi.suite.path:/api/v1/auth/suite}")
public class SuitePayController {

    private static final Logger log = LoggerFactory.getLogger(SuitePayController.class);

    private final SuitePurchases purchases;
    private final String provisionSecret;

    public SuitePayController(SuitePurchases purchases, String provisionSecret) {
        this.purchases = purchases;
        this.provisionSecret = provisionSecret == null ? "" : provisionSecret.trim();
        // Loud, but not fatal: a crash on deploy would take the whole app down over one missing setting, while
        // ID simply keeps retrying a paid purchase (for 30 days) until the secret is set.
        if (this.provisionSecret.isBlank()) {
            log.error("Magizhchi Pay: magizhchi.provision-secret (Magizhchi ID's provision secret) is not set, so paid "
                    + "purchases can't be delivered to this app. Set it; ID retries until then.");
        }
    }

    public record ActivateRequest(String email, String planCode, String cycle, String orderRef, Long amountPaise,
                                  String payId, String reference, String label, String kind) {}

    // ID's body is camelCase. Read it with a plain mapper, not the app's: an app whose JSON is snake_case would
    // otherwise see every field as null.
    private static final ObjectMapper WIRE = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

    @PostMapping("/activate")
    public ResponseEntity<Map<String, Object>> activate(@RequestHeader(value = "X-Provision-Secret", required = false) String secret,
                                                        @RequestBody(required = false) String body) {
        if (provisionSecret.isBlank()) {
            return ResponseEntity.status(503).body(Map.of("status", "ERROR", "message", "This app isn't set up to receive payments yet."));
        }
        if (!SharedSecret.matches(provisionSecret, secret)) {
            return ResponseEntity.status(403).body(Map.of("error", "Invalid provisioning secret."));
        }
        ActivateRequest req;
        try {
            req = body == null || body.isBlank() ? null : WIRE.readValue(body, ActivateRequest.class);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", "The request isn't valid JSON."));
        }
        if (req == null || blank(req.orderRef()) || blank(req.email()) || blank(req.planCode())) {
            return ResponseEntity.badRequest().body(Map.of("error", "email, planCode and orderRef are required."));
        }
        SuitePurchases.Purchase p = new SuitePurchases.Purchase(req.orderRef().trim(), req.email().trim().toLowerCase(),
                req.planCode().trim(), blank(req.cycle()) ? null : req.cycle().trim().toUpperCase(),
                req.amountPaise() == null ? 0 : req.amountPaise(), req.payId(), req.reference(), req.label(), req.kind());
        SuitePurchases.Delivery d;
        try {
            d = purchases.deliver(p);
        } catch (SuiteException | IllegalArgumentException | IllegalStateException e) {
            d = SuitePurchases.Delivery.failed(e.getMessage());
        } catch (RuntimeException e) {
            log.warn("Delivering {} failed", p.orderRef(), e);
            d = SuitePurchases.Delivery.failed("The app hit an error while applying it.");
        }
        if (d == null) d = SuitePurchases.Delivery.failed("The app gave no answer.");
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("status", d.status());
        if (d.endsAt() != null) out.put("endsAt", d.endsAt().toString());
        if (d.message() != null) out.put("message", d.message());
        return ResponseEntity.ok(out);
    }

    private static boolean blank(String s) {
        return s == null || s.isBlank();
    }
}
