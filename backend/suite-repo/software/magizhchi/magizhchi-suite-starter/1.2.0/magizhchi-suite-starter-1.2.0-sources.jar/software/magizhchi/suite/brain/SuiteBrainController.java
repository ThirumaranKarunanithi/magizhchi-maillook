package software.magizhchi.suite.brain;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.server.ResponseStatusException;
import software.magizhchi.suite.SuiteException;
import software.magizhchi.suite.SuiteProperties;
import software.magizhchi.suite.auth.Delegation;
import software.magizhchi.suite.auth.DelegationVerifier;
import software.magizhchi.suite.auth.SharedSecret;

import java.lang.reflect.Method;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * The two Suite Brain endpoints (protocol v1), served for every {@link SuiteTool} bean:
 * <ul>
 *   <li>{@code GET <path>/manifest} with {@code X-Provision-Secret}: the tool list.</li>
 *   <li>{@code POST <path>/tools/{name}} with {@code Authorization: Bearer <delegation>} and {@code {"input":{...}}}.</li>
 * </ul>
 * The path is {@code magizhchi.suite.path} (default {@code /api/v1/auth/suite}). An app with Spring Security must let
 * that path through its session filter: these endpoints check their own credentials.
 */
@Controller
@ResponseBody
@RequestMapping("${magizhchi.suite.path:/api/v1/auth/suite}")
public class SuiteBrainController {

    private static final Logger log = LoggerFactory.getLogger(SuiteBrainController.class);
    private static final Pattern NAME = Pattern.compile("[a-z0-9_]{1,40}");

    private final DelegationVerifier verifier;
    private final String paSecret;
    private final Map<String, SuiteTool> tools;

    public SuiteBrainController(DelegationVerifier verifier, SuiteProperties props, List<SuiteTool> tools) {
        this.verifier = verifier;
        this.paSecret = props.paSecret();
        for (SuiteTool t : tools) {
            if (!NAME.matcher(t.name()).matches()) {
                throw new IllegalStateException("Suite tool name '" + t.name() + "' must be lowercase letters, digits or _, at most 40.");
            }
            if (t.briefing() && t.risk() != SuiteTool.Risk.READ) {
                throw new IllegalStateException("Suite tool '" + t.name() + "' is a briefing tool, so it must be READ.");
            }
        }
        this.tools = tools.stream().collect(Collectors.toMap(SuiteTool::name, Function.identity(), (a, b) -> {
            throw new IllegalStateException("Two suite tools are named '" + a.name() + "'.");
        }, LinkedHashMap::new));
    }

    @GetMapping("/manifest")
    public Map<String, Object> manifest(@RequestHeader(value = "X-Provision-Secret", required = false) String secret) {
        if (!SharedSecret.matches(paSecret, secret)) throw SuiteException.forbidden("Invalid suite secret.");
        List<Map<String, Object>> list = tools.values().stream().map(t -> {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("name", t.name());
            m.put("risk", t.risk().wire());
            m.put("description", t.description());
            m.put("inputSchema", t.inputSchema());
            if (t.briefing()) m.put("briefing", true);
            if (t.personSearch()) m.put("personSearch", true);
            if (t.hidden()) m.put("hidden", true);
            return m;
        }).toList();
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("app", verifier.appName());
        out.put("version", 1);
        out.put("tools", list);
        return out;
    }

    @PostMapping("/tools/{name}")
    public Object run(@PathVariable("name") String name,
                      @RequestHeader(value = "Authorization", required = false) String authorization,
                      @RequestBody(required = false) Map<String, Object> body) {
        Delegation who = verifier.verifyHeader(authorization);
        SuiteTool tool = tools.get(name);
        if (tool == null) throw SuiteException.notFound("Unknown tool: " + name);
        if (tool.risk() != SuiteTool.Risk.READ && !who.canWrite()) throw SuiteException.forbidden("This token is read-only.");
        Map<String, Object> input = body != null && body.get("input") instanceof Map<?, ?> m ? cast(m) : Map.of();
        Object result = tool.run(who, input);
        return result == null ? Map.of("ok", true) : result;
    }

    @ExceptionHandler(SuiteException.class)
    public ResponseEntity<Map<String, Object>> suite(SuiteException e) {
        return error(e.status(), e.getMessage());
    }

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<Map<String, Object>> badInput(IllegalArgumentException e) {
        return error(400, e.getMessage() == null ? "Bad input." : e.getMessage());
    }

    @ExceptionHandler(ResponseStatusException.class)
    public ResponseEntity<Map<String, Object>> status(ResponseStatusException e) {
        return error(e.getStatusCode().value(), e.getReason() == null ? "Request refused." : e.getReason());
    }

    /**
     * Any other exception. An app exception that carries an HTTP status (its own ApiException with getStatus() or
     * status()) keeps that status and message; anything else is a bug: logged here, told to PA plainly, no stack trace.
     */
    @ExceptionHandler(RuntimeException.class)
    public ResponseEntity<Map<String, Object>> unexpected(RuntimeException e) {
        Integer code = statusOf(e);
        if (code != null && code >= 400 && code < 500 && e.getMessage() != null) return error(code, e.getMessage());
        log.error("Suite tool failed", e);
        return error(500, "Something went wrong in " + verifier.appName() + ". Try again in a minute.");
    }

    private static ResponseEntity<Map<String, Object>> error(int status, String message) {
        return ResponseEntity.status(HttpStatus.valueOf(status)).body(Map.of("error", message));
    }

    /** The HTTP status an app exception carries, read from getStatus() or status() (HttpStatusCode or a number). */
    static Integer statusOf(Throwable e) {
        for (String m : new String[]{"getStatus", "status", "getStatusCode"}) {
            try {
                Method method = e.getClass().getMethod(m);
                Object v = method.invoke(e);
                if (v instanceof HttpStatusCode s) return s.value();
                if (v instanceof Number n) return n.intValue();
            } catch (ReflectiveOperationException | RuntimeException ignored) {
                // not this one
            }
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> cast(Map<?, ?> m) {
        return (Map<String, Object>) m;
    }
}
