package software.magizhchi.suite.brain;

import software.magizhchi.suite.auth.Delegation;

import java.util.Map;

/**
 * One thing Magizhchi PA can read or do in this app. Declare each tool as a Spring bean; the starter lists it in the
 * manifest and runs it at {@code POST <path>/tools/{name}} after checking the delegation token, and refuses a
 * {@code write} or {@code danger} tool when the token is read-only, so a tool body never repeats those checks.
 *
 * <pre>
 * &#64;Component
 * class MyCompanies implements SuiteTool {
 *     public String name() { return "my_companies"; }
 *     public Risk risk() { return Risk.READ; }
 *     public String description() { return "The companies the person keeps books for..."; }
 *     public Map&lt;String, Object&gt; inputSchema() { return Schema.object().build(); }
 *     public Object run(Delegation who, Map&lt;String, Object&gt; input) { ... }
 * }
 * </pre>
 *
 * Throw {@link software.magizhchi.suite.SuiteException} (or IllegalArgumentException for bad input) with a sentence
 * the person can read; PA hands it to the model as the answer.
 */
public interface SuiteTool {

    enum Risk {
        /** No side effects; runs straight away. */
        READ,
        /** Changes data; PA asks the person first (or follows their AUTO setting). */
        WRITE,
        /** Deletes, sends money or messages; PA always asks. */
        DANGER;

        public String wire() {
            return name().toLowerCase();
        }
    }

    /** Lowercase letters, digits and underscores, at most 40 characters. */
    String name();

    Risk risk();

    String description();

    /** A JSON Schema object for the input, as Anthropic tools expect. {@link Schema} builds one. */
    Map<String, Object> inputSchema();

    /** Takes no input; its answer appears in PA's My Day and feeds nudges. READ tools only. */
    default boolean briefing() { return false; }

    /** Takes {"name"} and answers {"items":[{when,title,detail,kind,link}]} for PA's People timeline. */
    default boolean personSearch() { return false; }

    /** Exists only to undo another tool; never offered to the model. */
    default boolean hidden() { return false; }

    Object run(Delegation who, Map<String, Object> input);
}
