package software.magizhchi.suite.events;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import software.magizhchi.suite.auth.SharedSecret;

import java.time.Instant;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Where the events bus delivers: {@code POST <suite path>/events} with the suite secret and {@code {"events":[...]}}.
 * Each event goes to every {@link SuiteEventHandler} whose types match. Any handler failing answers 500, so the bus
 * sends the batch again later; handlers that already succeeded for an event are not called again for it (while this
 * server keeps running), and the others are.
 */
@Controller
@ResponseBody
@RequestMapping("${magizhchi.suite.path:/api/v1/auth/suite}")
public class SuiteEventsController {

    private static final Logger log = LoggerFactory.getLogger(SuiteEventsController.class);
    static final int REMEMBER = 20_000;

    // A plain mapper: the bus's wire format is camelCase whatever the app's own JSON naming is.
    private final ObjectMapper mapper = new ObjectMapper();
    private final List<SuiteEventHandler> handlers;
    private final String secret;
    private final Set<String> done = Collections.newSetFromMap(Collections.synchronizedMap(new LinkedHashMap<>(256, 0.75f, false) {
        @Override
        protected boolean removeEldestEntry(Map.Entry<String, Boolean> eldest) {
            return size() > REMEMBER;
        }
    }));

    public SuiteEventsController(List<SuiteEventHandler> handlers, String secret) {
        this.handlers = List.copyOf(handlers);
        this.secret = secret == null ? "" : secret.trim();
        if (this.secret.isBlank()) {
            log.error("Events bus: this app has event handlers but no suite secret (magizhchi.provision-secret), so it can't receive events.");
        }
    }

    @PostMapping("/events")
    public ResponseEntity<Map<String, Object>> receive(@RequestHeader(value = "X-Provision-Secret", required = false) String given,
                                                       @RequestBody(required = false) String body) {
        if (secret.isBlank()) return ResponseEntity.status(503).body(Map.of("ok", false, "error", "This app isn't set up to receive events yet."));
        if (!SharedSecret.matches(secret, given)) return ResponseEntity.status(403).body(Map.of("ok", false, "error", "Invalid provisioning secret."));
        JsonNode events;
        try {
            events = mapper.readTree(body == null ? "{}" : body).path("events");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("ok", false, "error", "Not JSON."));
        }
        int handled = 0;
        String problem = null;
        for (JsonNode n : events) {
            SuiteEventHandler.Event e = read(n);
            if (e.id() == null || e.type() == null) continue;
            for (int i = 0; i < handlers.size(); i++) {
                SuiteEventHandler h = handlers.get(i);
                if (!wants(h, e.type())) continue;
                String mark = e.id() + "|" + i;
                if (done.contains(mark)) continue;
                try {
                    h.handle(e);
                    done.add(mark);
                    handled++;
                } catch (Exception ex) {
                    log.warn("Event {} ({}) failed in {}: {}", e.id(), e.type(), h.getClass().getSimpleName(), ex.toString());
                    if (problem == null) problem = h.getClass().getSimpleName() + " failed on " + e.type();
                }
            }
        }
        if (problem != null) return ResponseEntity.status(500).body(Map.of("ok", false, "error", problem));
        return ResponseEntity.ok(Map.of("ok", true, "handled", handled));
    }

    static boolean wants(SuiteEventHandler h, String type) {
        List<String> types = h.types();
        if (types == null) return false;
        for (String p : types) {
            if (p == null) continue;
            if (p.endsWith(".*") ? type.startsWith(p.substring(0, p.length() - 1)) : p.equals(type)) return true;
        }
        return false;
    }

    @SuppressWarnings("unchecked")
    private SuiteEventHandler.Event read(JsonNode n) {
        Map<String, Object> data;
        try {
            data = n.hasNonNull("data") && n.get("data").isObject() ? mapper.convertValue(n.get("data"), Map.class) : Map.of();
        } catch (IllegalArgumentException ex) {
            data = Map.of();
        }
        UUID org = null;
        Instant at = null;
        try {
            if (n.hasNonNull("orgId")) org = UUID.fromString(n.get("orgId").asText());
        } catch (IllegalArgumentException ignored) {
            // not an id: leave it out
        }
        try {
            if (n.hasNonNull("occurredAt")) at = Instant.parse(n.get("occurredAt").asText());
        } catch (RuntimeException ignored) {
            // unreadable time: leave it out
        }
        return new SuiteEventHandler.Event(text(n, "id"), text(n, "app"), text(n, "type"), text(n, "key"), text(n, "ownerEmail"),
                org, at, Collections.unmodifiableMap(data));
    }

    private static String text(JsonNode n, String field) {
        return n.hasNonNull(field) ? n.get(field).asText() : null;
    }
}
