package software.magizhchi.suite;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * One set of setting names for every app. They keep the names most apps already use
 * ({@code magizhchi.jwt.secret}, {@code magizhchi.provision-secret}), so moving an app over needs no new
 * Railway variables in the common case.
 *
 * <pre>
 * magizhchi.jwt.secret            = ${MAGIZHCHI_JWT_SECRET}        the suite signing secret (same as Magizhchi ID)
 * magizhchi.jwt.issuer            = magizhchi-id                   the issuer Magizhchi ID writes into its tokens
 * magizhchi.jwt.require-issuer    = false                          true: reject tokens without iss=magizhchi-id
 * magizhchi.provision-secret      = ${MAGIZHCHI_PROVISION_SECRET}  the server-to-server secret (X-Provision-Secret)
 * magizhchi.suite.app-name        = Magizhchi Books                this app's name as Magizhchi ID knows it
 * magizhchi.suite.app-id          = books                          short id used in PA's activity feed
 * magizhchi.suite.path            = /api/v1/auth/suite             where the Suite Brain endpoints live
 * magizhchi.suite.secret          = (empty: use provision-secret)  the secret PA sends; set only if it differs
 * magizhchi.pa.url                = https://paback.magizhchi.software
 * magizhchi.provider.url          = https://api.provider.magizhchi.software
 * magizhchi.provider.api-key      = ${MAGIZHCHI_PROVIDER_KEY}      a Provider live key (mp_live_...)
 * magizhchi.id.url                = https://id-api...  Magizhchi ID's API (or the older magizhchi.base-url)
 * </pre>
 */
@ConfigurationProperties(prefix = "magizhchi")
public class SuiteProperties {

    private final Jwt jwt = new Jwt();
    private final Suite suite = new Suite();
    private final Pa pa = new Pa();
    private final Provider provider = new Provider();
    private final Id id = new Id();
    private String provisionSecret = "";
    private String baseUrl = "";

    public Jwt getJwt() { return jwt; }
    public Suite getSuite() { return suite; }
    public Pa getPa() { return pa; }
    public Provider getProvider() { return provider; }
    public Id getId() { return id; }
    /** The older name many apps use for the Magizhchi ID address ({@code magizhchi.base-url}). */
    public String getBaseUrl() { return baseUrl; }
    public void setBaseUrl(String baseUrl) { this.baseUrl = stripSlash(baseUrl); }

    /** Magizhchi ID's API address: {@code magizhchi.id.url}, else {@code magizhchi.base-url}. */
    public String idUrl() {
        return id.url.isBlank() ? baseUrl : id.url;
    }
    public String getProvisionSecret() { return provisionSecret; }
    public void setProvisionSecret(String provisionSecret) { this.provisionSecret = trim(provisionSecret); }

    /** This app's public address: {@code magizhchi.suite.public-url}, else https://$RAILWAY_PUBLIC_DOMAIN, else blank. */
    public String publicUrl() {
        if (!suite.publicUrl.isBlank()) return suite.publicUrl;
        String railway = System.getenv("RAILWAY_PUBLIC_DOMAIN");
        return railway == null || railway.isBlank() ? "" : "https://" + railway.trim();
    }

    /** Where Magizhchi ID tells this app a payment is paid: the suite path + /activate on the public address. */
    public String activateUrl() {
        String base = publicUrl();
        return base.isBlank() ? "" : base + suite.path.replaceAll("/+$", "") + "/activate";
    }

    /** Where the events bus delivers to this app: the suite path + /events on the public address. */
    public String eventsUrl() {
        String base = publicUrl();
        return base.isBlank() ? "" : base + suite.path.replaceAll("/+$", "") + "/events";
    }

    /** The secret PA presents to this app: {@code magizhchi.suite.secret} if set, else the provision secret. */
    public String paSecret() {
        return suite.secret.isBlank() ? provisionSecret : suite.secret;
    }

    public static class Jwt {
        private String secret = "";
        private String issuer = "magizhchi-id";
        private boolean requireIssuer = false;

        public String getSecret() { return secret; }
        public void setSecret(String secret) { this.secret = trim(secret); }
        public String getIssuer() { return issuer; }
        public void setIssuer(String issuer) { this.issuer = trim(issuer); }
        public boolean isRequireIssuer() { return requireIssuer; }
        public void setRequireIssuer(boolean requireIssuer) { this.requireIssuer = requireIssuer; }
    }

    public static class Suite {
        private String appName = "";
        private String appId = "";
        private String path = "/api/v1/auth/suite";
        private String secret = "";
        private String publicUrl = "";

        public String getAppName() { return appName; }
        public void setAppName(String appName) { this.appName = trim(appName); }
        public String getAppId() { return appId; }
        public void setAppId(String appId) { this.appId = trim(appId); }
        public String getPath() { return path; }
        public void setPath(String path) { this.path = trim(path); }
        public String getSecret() { return secret; }
        public void setSecret(String secret) { this.secret = trim(secret); }
        /** This app's own public https address (where ID can reach it). Blank: Railway's RAILWAY_PUBLIC_DOMAIN. */
        public String getPublicUrl() { return publicUrl; }
        public void setPublicUrl(String publicUrl) { this.publicUrl = stripSlash(publicUrl); }
    }

    public static class Pa {
        private String url = "https://paback.magizhchi.software";

        public String getUrl() { return url; }
        public void setUrl(String url) { this.url = stripSlash(url); }
    }

    public static class Id {
        private String url = "";

        public String getUrl() { return url; }
        public void setUrl(String url) { this.url = stripSlash(url); }
    }

    public static class Provider {
        private String url = "https://api.provider.magizhchi.software";
        private String apiKey = "";

        public String getUrl() { return url; }
        public void setUrl(String url) { this.url = stripSlash(url); }
        public String getApiKey() { return apiKey; }
        public void setApiKey(String apiKey) { this.apiKey = trim(apiKey); }
    }

    static String trim(String s) {
        return s == null ? "" : s.trim();
    }

    static String stripSlash(String s) {
        return trim(s).replaceAll("/+$", "");
    }
}
