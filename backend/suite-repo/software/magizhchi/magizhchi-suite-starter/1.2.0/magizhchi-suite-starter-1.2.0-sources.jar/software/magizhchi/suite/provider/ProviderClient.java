package software.magizhchi.suite.provider;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Sends email through Magizhchi Provider ({@code POST /v1/messages}), replacing Resend, plain SMTP and msg91 in the
 * apps. Provider queues the message and answers at once; delivery, bounces and opens show in the Provider dashboard
 * and in its webhooks.
 *
 * <pre>
 * provider.sendEmail(ProviderClient.Email.to("ravi@example.com")
 *         .from("no-reply@magizhchi.software", "Magizhchi Books")
 *         .subject("Your invoice")
 *         .html(html)
 *         .attach("INV-42.pdf", pdfBytes)
 *         .reference("invoice-42"));
 * </pre>
 */
public class ProviderClient {

    private final String baseUrl;
    private final String apiKey;
    private final ObjectMapper mapper;
    private final HttpClient http;

    public ProviderClient(String baseUrl, String apiKey, ObjectMapper mapper) {
        this(baseUrl, apiKey, mapper, HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build());
    }

    ProviderClient(String baseUrl, String apiKey, ObjectMapper mapper, HttpClient http) {
        this.baseUrl = baseUrl == null ? "" : baseUrl.trim().replaceAll("/+$", "");
        this.apiKey = apiKey == null ? "" : apiKey.trim();
        this.mapper = mapper;
        this.http = http;
    }

    /** True when a Provider key is set; apps keep their old sender while this is false. */
    public boolean configured() {
        return !apiKey.isBlank() && !baseUrl.isBlank();
    }

    /** Queues one email. Throws {@link ProviderException} when Provider refuses it or cannot be reached. */
    public Sent sendEmail(Email email) {
        if (!configured()) throw new ProviderException(0, "not_configured", "Magizhchi Provider is not configured (magizhchi.provider.api-key).", false);
        Map<String, Object> body = email.toJson();
        HttpRequest.Builder req = HttpRequest.newBuilder(URI.create(baseUrl + "/v1/messages"))
                .timeout(Duration.ofSeconds(20))
                .header("Content-Type", "application/json")
                .header("Authorization", "Bearer " + apiKey);
        if (email.idempotencyKey != null) req.header("Idempotency-Key", email.idempotencyKey);
        JsonNode res = call(req.POST(HttpRequest.BodyPublishers.ofString(write(body))).build());
        return new Sent(res.path("id").asText(null), res.path("status").asText(null));
    }

    /** A message's current status: QUEUED, SENT, DELIVERED, OPENED, BOUNCED, FAILED... */
    public String status(String messageId) {
        if (!configured()) throw new ProviderException(0, "not_configured", "Magizhchi Provider is not configured.", false);
        HttpRequest req = HttpRequest.newBuilder(URI.create(baseUrl + "/v1/messages/" + messageId))
                .timeout(Duration.ofSeconds(10))
                .header("Authorization", "Bearer " + apiKey)
                .GET().build();
        return call(req).path("status").asText(null);
    }

    private JsonNode call(HttpRequest req) {
        HttpResponse<String> res;
        try {
            res = http.send(req, HttpResponse.BodyHandlers.ofString());
        } catch (IOException e) {
            throw new ProviderException(0, "unreachable", "Could not reach Magizhchi Provider: " + e.getMessage(), true);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new ProviderException(0, "interrupted", "Interrupted while calling Magizhchi Provider.", true);
        }
        JsonNode node;
        try {
            node = res.body() == null || res.body().isBlank() ? mapper.createObjectNode() : mapper.readTree(res.body());
        } catch (IOException e) {
            node = mapper.createObjectNode();
        }
        int code = res.statusCode();
        if (code >= 300) {
            String message = node.path("error").asText(node.path("message").asText("Magizhchi Provider answered " + code + "."));
            throw new ProviderException(code, node.path("code").asText("http_" + code), message, code == 429 || code >= 500);
        }
        return node;
    }

    private String write(Object o) {
        try {
            return mapper.writeValueAsString(o);
        } catch (IOException e) {
            throw new IllegalStateException(e);
        }
    }

    /** Provider accepted the message. {@code status} is normally QUEUED. */
    public record Sent(String id, String status) {}

    /** One email. Build it with {@link #to(String)}; {@code html} or {@code text} (or both) is required. */
    public static final class Email {
        private final String to;
        private String from;
        private String fromName;
        private String replyTo;
        private String subject;
        private String html;
        private String text;
        private String reference;
        private String idempotencyKey;
        private final List<Map<String, Object>> attachments = new ArrayList<>();

        private Email(String to) {
            if (to == null || to.isBlank()) throw new IllegalArgumentException("to is required");
            this.to = to.trim();
        }

        public static Email to(String address) { return new Email(address); }

        /** An address on a domain verified in Provider, e.g. no-reply@magizhchi.software, and the name people see. */
        public Email from(String address, String name) { this.from = address; this.fromName = name; return this; }
        public Email replyTo(String address) { this.replyTo = address; return this; }
        public Email subject(String subject) { this.subject = subject; return this; }
        public Email html(String html) { this.html = html; return this; }
        public Email text(String text) { this.text = text; return this; }
        /** Your own id for this message (an invoice number, an OTP request id); shown in the dashboard and webhooks. */
        public Email reference(String reference) { this.reference = reference; return this; }
        /** Sending again with the same key returns the first message instead of a second email. */
        public Email idempotencyKey(String key) { this.idempotencyKey = key; return this; }

        public Email attach(String filename, byte[] content) { return attach(filename, content, null); }

        public Email attach(String filename, byte[] content, String contentType) {
            Map<String, Object> a = new LinkedHashMap<>();
            a.put("filename", filename);
            a.put("content", Base64.getEncoder().encodeToString(content));
            if (contentType != null) a.put("content_type", contentType);
            attachments.add(a);
            return this;
        }

        Map<String, Object> toJson() {
            if ((html == null || html.isBlank()) && (text == null || text.isBlank())) {
                throw new IllegalArgumentException("An email needs html or text.");
            }
            Map<String, Object> b = new LinkedHashMap<>();
            b.put("channel", "email");
            b.put("to", to);
            put(b, "from", from);
            put(b, "from_name", fromName);
            put(b, "reply_to", replyTo);
            put(b, "subject", subject);
            put(b, "html", html);
            put(b, "text", text);
            put(b, "reference", reference);
            if (!attachments.isEmpty()) b.put("attachments", List.copyOf(attachments));
            return b;
        }

        private static void put(Map<String, Object> b, String k, String v) {
            if (v != null && !v.isBlank()) b.put(k, v);
        }
    }
}
