package software.magizhchi.suite.auth;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

/**
 * Server-to-server secret checks ({@code X-Provision-Secret} and friends), in constant time. A blank configured
 * secret never matches, so an app with the variable missing is closed, not open.
 */
public final class SharedSecret {

    private SharedSecret() {}

    public static boolean matches(String configured, String given) {
        if (configured == null || configured.isBlank() || given == null) return false;
        return MessageDigest.isEqual(configured.trim().getBytes(StandardCharsets.UTF_8), given.trim().getBytes(StandardCharsets.UTF_8));
    }
}
