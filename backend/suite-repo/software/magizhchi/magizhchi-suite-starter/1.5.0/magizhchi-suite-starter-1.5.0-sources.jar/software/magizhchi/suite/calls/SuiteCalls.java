package software.magizhchi.suite.calls;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import software.magizhchi.suite.SuiteException;

import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Calls through Magizhchi Meet, the suite's calling hub. This app's server places, follows and cancels a call for
 * the person signed in here, naming both people by their Magizhchi ID account; Meet rings the person called on
 * every Magizhchi screen and phone where it can reach them. Calling is never built inside another app.
 *
 * <p>Who may call whom is Meet's call: friends (the one list in ID), teammates (same ID organisation) and
 * people who share a Meet room; a block in any app always stops it. A refusal comes back as a
 * {@link SuiteException} with status 403; "this person has never used Meet" as 404 (offer a phone call then).
 *
 * <p>Uses {@code magizhchi.meet.url}, the provision secret and {@code magizhchi.suite.app-name}.
 */
public class SuiteCalls {

    /** A call that started ringing. {@code joinUrl} is the room the caller opens to be in the call. */
    public record Started(String callId, String cardId, String joinUrl, String to, boolean reachable, int ringSeconds) {}

    /** How a call stands. {@code status}: ringing, answered, declined or missed. {@code seconds}: talk time once over. */
    public record Status(String callId, String status, String kind, String answeredAt, String endedAt, Long seconds) {
        public boolean over() { return endedAt != null || "declined".equals(status) || "missed".equals(status); }
    }

    /** One place a person can be rung: an app open on a device. {@code active}: touched in the last 2 minutes. */
    public record Screen(String app, String device, String client, boolean active) {}

    /** Where a person can be rung now. {@code onMeet} false: they have never used Meet, nothing to ring. */
    public record Presence(boolean onMeet, boolean reachable, int phones, List<Screen> screens) {}

    private final String meetUrl;
    private final String secret;
    private final String app;
    private final ObjectMapper mapper;
    private final HttpClient http;

    public SuiteCalls(String meetUrl, String secret, String app, ObjectMapper mapper) {
        this(meetUrl, secret, app, mapper, HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build());
    }

    SuiteCalls(String meetUrl, String secret, String app, ObjectMapper mapper, HttpClient http) {
        this.meetUrl = meetUrl == null ? "" : meetUrl.trim().replaceAll("/+$", "");
        this.secret = secret == null ? "" : secret.trim();
        this.app = app == null ? "" : app.trim();
        this.mapper = mapper;
        this.http = http;
    }

    /** True when Meet's address, the provision secret and this app's name are all set. */
    public boolean configured() {
        return !meetUrl.isBlank() && !secret.isBlank() && !app.isBlank();
    }

    /**
     * Ring {@code toAccountId} for the caller. The caller's email and name are needed only the first time they
     * call (Meet makes them an account linked to their ID account); pass them always, it costs nothing.
     *
     * @param kind "voice" or "video"
     */
    public Started call(String fromAccountId, String fromEmail, String fromName, String toAccountId, String kind) {
        Map<String, Object> from = new LinkedHashMap<>();
        from.put("accountId", fromAccountId);
        from.put("email", fromEmail);
        from.put("name", fromName);
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("from", from);
        body.put("to", toAccountId);
        body.put("kind", kind == null || kind.isBlank() ? "video" : kind);
        body.put("app", app);
        JsonNode n = send("POST", "/api/v1/suite/calls", body);
        return new Started(text(n, "callId"), text(n, "cardId"), text(n, "joinUrl"), text(n, "to"),
                n.path("rangOn").path("reachable").asBoolean(false), n.path("ringSeconds").asInt(45));
    }

    /** How the call stands, asked as one of its two people. */
    public Status status(String callId, String asAccountId) {
        JsonNode n = send("GET", "/api/v1/suite/calls/" + enc(callId) + "?as=" + enc(asAccountId), null);
        return new Status(text(n, "callId"), text(n, "status"), text(n, "kind"), text(n, "answeredAt"), text(n, "endedAt"),
                n.hasNonNull("seconds") ? n.get("seconds").asLong() : null);
    }

    /** The caller gives up (or hangs up): every ring stops, and the person called sees a missed call. */
    public void cancel(String callId, String callerAccountId) {
        send("POST", "/api/v1/suite/calls/" + enc(callId) + "/cancel", Map.of("accountId", nz(callerAccountId)));
    }

    /** Where {@code accountId} can be rung now. Only for someone allowed to call them (else 403). */
    public Presence presence(String accountId, String askerAccountId) {
        JsonNode n = send("GET", "/api/v1/suite/presence/" + enc(accountId) + "?asker=" + enc(askerAccountId), null);
        List<Screen> screens = new ArrayList<>();
        for (JsonNode s : n.path("screens")) {
            screens.add(new Screen(text(s, "app"), text(s, "device"), text(s, "client"), s.path("active").asBoolean(false)));
        }
        return new Presence(n.path("onMeet").asBoolean(false), n.path("reachable").asBoolean(false),
                n.path("phones").asInt(0), List.copyOf(screens));
    }

    /**
     * This app is open for the person on this device. Call it about once a minute while the app is open, and
     * with {@code touched} true when they use it, so a call rings where they actually are.
     */
    public void seen(String accountId, String device, String client, boolean touched) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("app", app);
        body.put("device", device);
        body.put("client", client);
        body.put("touched", touched);
        send("POST", "/api/v1/suite/presence/" + enc(accountId) + "/seen", body);
    }

    /**
     * A ring pass for the call bar ({@code meet.magizhchi.software/sdk/magizhchi-call.js}) in this app, for the
     * person signed in here. Return {@link RingPass#raw()} to your page as is; the script reads it. Your endpoint
     * must only ever hand a person their OWN pass.
     *
     * @param device the call bar's device id (it sends one), so two machines ring as two places
     */
    public RingPass ringPass(String accountId, String email, String name, String device) {
        Map<String, Object> from = new LinkedHashMap<>();
        from.put("accountId", accountId);
        from.put("email", email);
        from.put("name", name);
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("from", from);
        body.put("app", app);
        body.put("device", device == null || device.isBlank() ? "unknown" : device);
        JsonNode n = send("POST", "/api/v1/suite/ring-pass", body);
        @SuppressWarnings("unchecked")
        Map<String, Object> raw = mapper.convertValue(n, Map.class);
        return new RingPass(text(n, "pass"), text(n, "expiresAt"), java.util.Collections.unmodifiableMap(new LinkedHashMap<>(raw)));
    }

    /** A call bar's pass. {@code raw}: everything Meet sent (pass, expiresAt, apiUrl, socketUrl, webUrl, name). */
    public record RingPass(String pass, String expiresAt, Map<String, Object> raw) {}

    /** This app was closed (or signed out) on that device. */
    public void gone(String accountId, String device) {
        send("POST", "/api/v1/suite/presence/" + enc(accountId) + "/gone", Map.of("app", app, "device", nz(device)));
    }

    // ───────────────────────── helpers ─────────────────────────

    private JsonNode send(String method, String path, Object body) {
        if (!configured()) {
            throw SuiteException.notConfigured("Magizhchi Meet calls (magizhchi.meet.url, magizhchi.provision-secret, magizhchi.suite.app-name)");
        }
        HttpRequest.Builder b = HttpRequest.newBuilder(URI.create(meetUrl + path))
                .timeout(Duration.ofSeconds(10))
                .header("X-Provision-Secret", secret);
        if (body != null) {
            try {
                b.header("Content-Type", "application/json")
                        .method(method, HttpRequest.BodyPublishers.ofString(mapper.writeValueAsString(body)));
            } catch (IOException e) {
                throw new IllegalStateException(e);
            }
        } else {
            b.method(method, HttpRequest.BodyPublishers.noBody());
        }
        HttpResponse<String> res;
        try {
            res = http.send(b.build(), HttpResponse.BodyHandlers.ofString());
        } catch (IOException e) {
            throw new SuiteException(503, "meet_unreachable", "Magizhchi Meet can't be reached right now. Try again in a minute.");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new SuiteException(503, "interrupted", "Interrupted while calling Magizhchi Meet.");
        }
        JsonNode n;
        try {
            n = res.body() == null || res.body().isBlank() ? mapper.createObjectNode() : mapper.readTree(res.body());
        } catch (IOException e) {
            n = mapper.createObjectNode();
        }
        int code = res.statusCode();
        if (code >= 300) {
            String msg = n.path("message").asText(n.path("error").asText("Magizhchi Meet answered " + code + "."));
            boolean wrongSecret = code == 403 && msg.toLowerCase().contains("provision secret");
            throw new SuiteException(wrongSecret ? 503 : code, "meet_" + code,
                    wrongSecret ? "This app's provision secret is wrong for Magizhchi Meet (magizhchi.provision-secret)." : msg);
        }
        return n;
    }

    private static String text(JsonNode n, String field) {
        JsonNode v = n.get(field);
        return v == null || v.isNull() ? null : v.asText();
    }

    private static String nz(String s) {
        return s == null ? "" : s;
    }

    private static String enc(String s) {
        return URLEncoder.encode(nz(s), StandardCharsets.UTF_8);
    }
}
