package software.magizhchi.suite.friends;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import software.magizhchi.suite.SuiteException;

import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * The suite's one friend list and block list, kept in Magizhchi ID. An app's own Friends screen shows and changes it
 * for the person signed in to the app, named by their Magizhchi ID account id. A block made in any app holds in every
 * app: before a call, a message or a share between two people, ask {@link #relation}.
 *
 * <p>Nothing is cached: the list changes from other apps at any moment.
 */
public class SuiteFriends {

    /** One person on the list. {@code at} is when they became friends, the request was sent, or the block made. */
    public record Person(String accountId, String name, String email, String requestId, String sourceApp, Instant at) {}

    public record FriendList(List<Person> friends, List<Person> incoming, List<Person> outgoing, List<Person> blocked) {}

    /** How two people stand. {@code pending} is "sent" (a asked b), "received" (b asked a) or null. */
    public record Relation(boolean friends, String pending, boolean blocked, boolean youBlocked) {}

    /** After a request or accept: {@code status} is FRIENDS, SENT or RECEIVED. */
    public record Result(String requestId, String accountId, String status) {}

    /** One row of an app's own list, for the one-time move into ID. {@code status} ACCEPTED or PENDING. */
    public record ImportFriend(String from, String to, String status, Instant createdAt, Instant acceptedAt) {}

    public record ImportBlock(String blocker, String blocked, Instant createdAt) {}

    private final String idUrl;
    private final String secret;
    private final String app;
    private final ObjectMapper mapper;
    private final HttpClient http;

    public SuiteFriends(String idUrl, String secret, String app, ObjectMapper mapper) {
        this(idUrl, secret, app, mapper, HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build());
    }

    SuiteFriends(String idUrl, String secret, String app, ObjectMapper mapper, HttpClient http) {
        this.idUrl = idUrl == null ? "" : idUrl.trim().replaceAll("/+$", "");
        this.secret = secret == null ? "" : secret.trim();
        this.app = app == null ? "" : app.trim();
        this.mapper = mapper;
        this.http = http;
    }

    /** True when the ID address, the provision secret and this app's name are all set. */
    public boolean configured() {
        return !idUrl.isBlank() && !secret.isBlank() && !app.isBlank();
    }

    // ───────────────────────── reading ─────────────────────────

    /** The person's friends, requests both ways and the people they blocked. */
    public FriendList list(String accountId) {
        JsonNode n = call("GET", "/" + enc(accountId), null);
        return new FriendList(people(n.path("friends"), "since"), people(n.path("incoming"), "sentAt"),
                people(n.path("outgoing"), "sentAt"), people(n.path("blocked"), "blockedAt"));
    }

    /** Account ids the person is out of contact with through a block, either way: leave them out of searches. */
    public List<String> outOfContact(String accountId) {
        JsonNode n = call("GET", "/" + enc(accountId) + "/out-of-contact", null);
        List<String> out = new ArrayList<>();
        n.forEach(v -> out.add(v.asText()));
        return List.copyOf(out);
    }

    /** How {@code a} stands with {@code b}. */
    public Relation relation(String a, String b) {
        JsonNode n = call("GET", "/relation?a=" + enc(a) + "&b=" + enc(b), null);
        return new Relation(n.path("friends").asBoolean(false), text(n, "pending"), n.path("blocked").asBoolean(false),
                n.path("youBlocked").asBoolean(false));
    }

    /** May these two call, message or share with each other? False when either blocked the other. */
    public boolean inContact(String a, String b) {
        return !relation(a, b).blocked();
    }

    // ───────────────────────── changing ─────────────────────────

    /** Ask {@code otherId}. If they had already asked, the two become friends at once. */
    public Result request(String accountId, String otherId) {
        return result(call("POST", "/" + enc(accountId) + "/requests/" + enc(otherId) + "?app=" + enc(app), null));
    }

    public Result accept(String accountId, String requestId) {
        return result(call("POST", "/" + enc(accountId) + "/requests/" + enc(requestId) + "/accept", null));
    }

    public void decline(String accountId, String requestId) {
        call("POST", "/" + enc(accountId) + "/requests/" + enc(requestId) + "/decline", null);
    }

    public void cancel(String accountId, String requestId) {
        call("POST", "/" + enc(accountId) + "/requests/" + enc(requestId) + "/cancel", null);
    }

    /** Unfriend, or drop a request either way. Safe to repeat. */
    public void remove(String accountId, String otherId) {
        call("DELETE", "/" + enc(accountId) + "/friends/" + enc(otherId), null);
    }

    /** Block in every Magizhchi app: ends the friendship and any request. */
    public void block(String accountId, String otherId) {
        call("POST", "/" + enc(accountId) + "/blocks/" + enc(otherId) + "?app=" + enc(app), null);
    }

    public void unblock(String accountId, String otherId) {
        call("DELETE", "/" + enc(accountId) + "/blocks/" + enc(otherId), null);
    }

    /**
     * Move this app's own friend list into ID, once (safe to repeat). Returns ID's counts: friendsAdded,
     * requestsAdded, requestsMadeFriends, blocksAdded, alreadyThere, skipped.
     */
    public Map<String, Object> importList(List<ImportFriend> friendships, List<ImportBlock> blocks) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("app", app);
        // dates go as ISO text, so any ObjectMapper (with or without the java.time module) can send them
        List<Map<String, Object>> rows = new ArrayList<>();
        for (ImportFriend r : friendships == null ? List.<ImportFriend>of() : friendships) {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("from", r.from());
            m.put("to", r.to());
            m.put("status", r.status());
            m.put("createdAt", r.createdAt() == null ? null : r.createdAt().toString());
            m.put("acceptedAt", r.acceptedAt() == null ? null : r.acceptedAt().toString());
            rows.add(m);
        }
        List<Map<String, Object>> blockRows = new ArrayList<>();
        for (ImportBlock r : blocks == null ? List.<ImportBlock>of() : blocks) {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("blocker", r.blocker());
            m.put("blocked", r.blocked());
            m.put("createdAt", r.createdAt() == null ? null : r.createdAt().toString());
            blockRows.add(m);
        }
        body.put("friendships", rows);
        body.put("blocks", blockRows);
        JsonNode n = call("POST", "/import", body);
        Map<String, Object> out = new LinkedHashMap<>();
        n.fields().forEachRemaining(e -> out.put(e.getKey(), e.getValue().isNumber() ? e.getValue().asInt() : e.getValue().asText()));
        return out;
    }

    // ───────────────────────── helpers ─────────────────────────

    private JsonNode call(String method, String path, Object body) {
        if (!configured()) {
            throw SuiteException.notConfigured("Magizhchi ID friends (magizhchi.id.url, magizhchi.provision-secret, magizhchi.suite.app-name)");
        }
        HttpRequest.Builder b = HttpRequest.newBuilder(URI.create(idUrl + "/api/v1/provision/friends" + path))
                .timeout(Duration.ofSeconds(10))
                .header("X-Provision-Secret", secret);
        if (body != null) {
            try {
                b.header("Content-Type", "application/json")
                        .method(method, HttpRequest.BodyPublishers.ofString(mapper.writeValueAsString(body)));
            } catch (IOException e) {
                throw new IllegalStateException(e);
            }
        } else {
            b.method(method, HttpRequest.BodyPublishers.noBody());
        }
        HttpResponse<String> res;
        try {
            res = http.send(b.build(), HttpResponse.BodyHandlers.ofString());
        } catch (IOException e) {
            throw new SuiteException(503, "id_unreachable", "Magizhchi ID can't be reached right now. Try again in a minute.");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new SuiteException(503, "interrupted", "Interrupted while calling Magizhchi ID.");
        }
        JsonNode n;
        try {
            n = res.body() == null || res.body().isBlank() ? mapper.createObjectNode() : mapper.readTree(res.body());
        } catch (IOException e) {
            n = mapper.createObjectNode();
        }
        if (res.statusCode() >= 300) {
            String msg = n.path("message").asText(n.path("error").asText("Magizhchi ID answered " + res.statusCode() + "."));
            throw new SuiteException(res.statusCode() == 403 ? 503 : res.statusCode(), "id_" + res.statusCode(),
                    res.statusCode() == 403 ? "This app's Magizhchi ID secret is wrong (magizhchi.provision-secret)." : msg);
        }
        return n;
    }

    private static List<Person> people(JsonNode arr, String atField) {
        List<Person> out = new ArrayList<>();
        for (JsonNode p : arr) {
            out.add(new Person(text(p, "accountId"), text(p, "name"), text(p, "email"), text(p, "requestId"),
                    text(p, "sourceApp"), instant(p.get(atField))));
        }
        return List.copyOf(out);
    }

    /** ID sends ISO text; a number (seconds, with or without a fraction) is read too. */
    static Instant instant(JsonNode v) {
        if (v == null || v.isNull()) return null;
        if (v.isNumber()) {
            double d = v.asDouble();
            return d > 1e12 ? Instant.ofEpochMilli((long) d) : Instant.ofEpochSecond((long) d, (long) ((d - Math.floor(d)) * 1e9));
        }
        try {
            return Instant.parse(v.asText());
        } catch (RuntimeException e) {
            return null;
        }
    }

    private static Result result(JsonNode n) {
        return new Result(text(n, "requestId"), text(n, "accountId"), text(n, "status"));
    }

    private static String text(JsonNode n, String field) {
        JsonNode v = n.get(field);
        return v == null || v.isNull() ? null : v.asText();
    }

    private static String enc(String s) {
        return URLEncoder.encode(s == null ? "" : s, StandardCharsets.UTF_8);
    }
}
